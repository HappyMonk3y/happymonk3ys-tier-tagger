# HappyMonk3y's Tier Tagger

Fabric client mod with MCTiers v2 name lookups, compact nametag/tab badges, Classic and MCTiers icons, custom tier colors, Mod Menu settings, and `/tiers <player>` search.

## Building

The exact Minecraft, Fabric API, Mod Menu, mapping, and Java versions are pinned in `versions.json`. This project builds a separate JAR for each Minecraft release. Install JDK 21 for 1.21.x targets and JDK 25 for 26.x targets. Gradle 9.6.0 is provided through the wrapper. Java 25 can run Gradle for all targets when both JDKs are installed and discoverable by Gradle.

```sh
./gradlew build -Pmc=1.21.11
./gradlew build -Pmc=26.3
```

On Windows, use `gradlew.bat`. In PowerShell, quote a property containing dots: `gradlew.bat build '-Pmc=1.21.11'`.

The result is `build/<minecraft>/libs/happymonk3ys-tier-tagger-1.7.0+mc<minecraft>.jar`. Use the file without `-sources` in the Minecraft `mods` folder. Install the matching Fabric API and Mod Menu versions and Fabric Loader 0.19.5 or newer. Never install more than one Tier Tagger JAR at the same time.

PowerShell can build the complete matrix with `./build-all.ps1`. Add `-Smoke` to launch each version's isolated development client and check its screens, icons and local tier display. The clients close automatically and store data under `build/<minecraft>/smoke`, separate from an installed game.

## Source structure

- `src/yarn/java`: 1.21.11 source, adapted to earlier 1.21 versions by `ports.gradle`.
- `src/mojang/java`: source using the unobfuscated names and rendering API for 26.x.
- `src/main/resources`: shared fonts, icons, metadata and localization.
- `src/test`: deterministic API contract, ranking, request and cache tests.
- `src/smoke`: development-only client checks; not included in release JARs.

Every `build` runs the core checks. Each `-sources.jar` contains the generated source for that exact Minecraft target. This source archive also includes the templates, adaptation script, build configuration and wrapper needed to rebuild all targets.

## Custom display

HappyMonk3y displays as RLT2 in Crystal and LT3 in all other gamemodes. This is a local cosmetic override and does not modify official MCTiers rankings. Retired tiers use `#8FB6DC` by default. Settings are saved in `config/mctiers-tagger.json`.

## License

Combined distribution: **GPL-3.0-only**. Classic and MCTiers icons are from the GPL-licensed Tiers resource pack. See `LICENSE` and `THIRD_PARTY_NOTICES.txt`. Independently authored code and the original generated app/fallback icon are also available under `LICENSE-MIT.txt`.

Source repository: https://github.com/HappyMonk3y/happymonk3ys-tier-tagger

Not endorsed by MCTiers, PvPTiers, Mojang, or Microsoft.
