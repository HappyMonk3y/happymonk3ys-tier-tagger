package dev.mctierstag;

import com.terraformersmc.modmenu.ModMenu;
import dev.mctierstag.api.PlayerProfile.Ranking;
import dev.mctierstag.ui.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import java.util.UUID;

/** Isolated development client: exercises each port's actual widgets, fonts and loaded mixins. */
public final class PortSmoke implements ClientModInitializer {
    private int stage, ticks;
    private void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    @Override public void onInitializeClient() {
        MCTiersTagger.LOGGER.info("PORT_SMOKE_START");
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getOverlay() != null || client.currentScreen == null) return;
            if (++ticks % 12 != 0) return;
            try {
                var mod = MCTiersTagger.get();
                switch (stage++) {
                    case 0 -> {
                        mod.config = new TaggerConfig();
                        check(ModMenu.hasConfigScreen("mctiers_tagger"), "Mod Menu entry");
                        var settings = ModMenu.getConfigScreen("mctiers_tagger", client.currentScreen);
                        check(settings instanceof SettingsScreen, "settings factory");
                        client.setScreen(settings);
                        check(settings.children().stream().filter(ButtonWidget.class::isInstance).count() == 7, "settings controls");
                        check(settings.children().stream().filter(TextFieldWidget.class::isInstance).count() == 1, "search field");
                        for (var mode : mod.api.modes().keySet()) for (var style : new String[]{"classic", "mctiers"})
                            check(client.textRenderer.getWidth(TierBadge.icon(mode, style)) > 0, "bitmap icon " + style + " " + mode);
                        mod.config.mode = "vanilla";
                        var tag = mod.decorate(UUID.nameUUIDFromBytes("OfflinePlayer:HappyMonk3y".getBytes()), "HappyMonk3y", Text.literal("HappyMonk3y"), false);
                        check(tag.getString().contains("RLT2 HappyMonk3y"), "offline retired tag");
                        check(TierBadge.color(new Ranking(2,1,2,1,true), mod.config) == 0x8FB6DC, "retired blue");
                        var original = Text.literal("Name");
                        TierBadge.decorate(original, new Ranking(3,1,null,null,false), "sword", mod.config);
                        check(original.getString().equals("Name"), "original name preserved");
                    }
                    case 1 -> client.setScreen(new TierColorsScreen(client.currentScreen));
                    case 2 -> client.setScreen(new TierColorScreen(client.currentScreen, new Ranking(2,1,2,1,true)));
                    case 3 -> client.setScreen(new ExtraOptionsScreen(client.currentScreen));
                    case 4 -> client.setScreen(new ProfileScreen(client.currentScreen, "HappyMonk3y"));
                    case 5 -> {
                        MCTiersTagger.LOGGER.info("PORT_SMOKE_PASS: settings, search, palettes, swatches, profile, icons and offline override");
                        client.scheduleStop();
                    }
                }
            } catch (Throwable failure) {
                MCTiersTagger.LOGGER.error("PORT_SMOKE_FAIL", failure);
                System.exit(1);
            }
        });
    }
}
