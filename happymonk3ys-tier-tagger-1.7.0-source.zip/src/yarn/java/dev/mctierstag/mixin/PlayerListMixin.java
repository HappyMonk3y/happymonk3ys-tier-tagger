package dev.mctierstag.mixin;

import dev.mctierstag.MCTiersTagger;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerListHud.class)
public abstract class PlayerListMixin {
    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void mctiers$addTier(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        if (MCTiersTagger.get() != null)
            cir.setReturnValue(MCTiersTagger.get().decorate(entry.getProfile().id(), entry.getProfile().name(), cir.getReturnValue(), true));
    }
}
