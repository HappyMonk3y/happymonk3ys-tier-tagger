package dev.mctierstag;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.mctierstag.api.MCTiersApi;
import dev.mctierstag.api.PlayerProfile;
import dev.mctierstag.ui.ProfileScreen;
import dev.mctierstag.ui.TierBadge;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;
import org.slf4j.*;
import java.nio.file.Path;
import java.util.UUID;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;

public final class MCTiersTagger implements ClientModInitializer {
    public static final String NAME = "HappyMonk3y's Tier Tagger";
    public static final Logger LOGGER = LoggerFactory.getLogger("HappyMonk3yTierTagger");
    private static MCTiersTagger instance;
    // Preserve the existing mod ID/config path when replacing v1.0.
    private final Path configPath = FabricLoader.getInstance().getConfigDir().resolve("mctiers-tagger.json");
    public final MCTiersApi api = new MCTiersApi();
    public TaggerConfig config;
    private String requestedProfile;
    private Object requestedConnection;

    public static MCTiersTagger get() { return instance; }
    @Override public void onInitializeClient() {
        instance = this;
        config = TaggerConfig.load(configPath);
        save();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (requestedProfile != null) {
                String name = requestedProfile;
                requestedProfile = null;
                if (client.getNetworkHandler() == requestedConnection && client.world != null)
                    client.setScreen(new ProfileScreen(null, name));
                requestedConnection = null;
            }
            if (client.world != null && config.enabled) api.loadModes();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> api.close());
        registerCommands();
        LOGGER.info("{} initialized for Fabric using {}", NAME, MCTiersApi.BASE_URL);
    }
    public boolean save() { return config.save(configPath); }

    public Text decorate(UUID uuid, String playerName, Text original, boolean tab) {
        if (!config.enabled || (tab && !config.tabList)) return original;
        PlayerProfile profile = LocalTierOverrides.appliesTo(playerName)
                ? LocalTierOverrides.profile(uuid, api.modes().keySet()) : api.cachedOrRequest(uuid, playerName);
        if (profile == null) return original;
        var selected = profile.select(config.mode, config.fallback, config.includeRetired);
        if (selected.isEmpty()) return original;
        var selection = selected.get();
        return TierBadge.decorate(original, selection.ranking(), selection.mode(), config);
    }
    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
                literal("tiers")
                    .executes(ctx -> {
                        ctx.getSource().sendFeedback(Text.literal("Use /tiers <player> to see every gamemode. Settings: Mods > " + NAME + " > Configure.").formatted(Formatting.GRAY));
                        return 1;
                    })
                    .then(argument("player", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            var handler = ctx.getSource().getClient().getNetworkHandler();
                            if (handler != null) handler.getPlayerList().stream().map(p -> p.getProfile().name())
                                    .filter(n -> n.toLowerCase(java.util.Locale.ROOT).startsWith(builder.getRemainingLowerCase()))
                                    .forEach(builder::suggest);
                            return builder.buildFuture();
                        }).executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "player");
                            if (!name.matches("[A-Za-z0-9_]{1,16}")) {
                                ctx.getSource().sendError(Text.literal("Use a Java username (1-16 letters, digits or _)."));
                                return 0;
                            }
                            // Open after the chat screen closes, so it stays visible.
                            requestedProfile = name;
                            requestedConnection = ctx.getSource().getClient().getNetworkHandler();
                            return 1;
                        }))));
    }
}

