package dev.mctierstag.ui;

import dev.mctierstag.TaggerConfig;
import dev.mctierstag.api.PlayerProfile.Ranking;
import net.minecraft.text.*;
import net.minecraft.util.Identifier;

/** One compact label shared by nametags, tab, profiles and the settings preview. */
public final class TierBadge {
    private static final String FALLBACK_GLYPH = "\ue000";
    private static final StyleSpriteSource BADGE_FONT = new StyleSpriteSource.Font(Identifier.of("mctiers_tagger", "badge"));
    private static final StyleSpriteSource CLASSIC_FONT = new StyleSpriteSource.Font(Identifier.of("mctiers_tagger", "classic"));
    private static final StyleSpriteSource MCTIERS_FONT = new StyleSpriteSource.Font(Identifier.of("mctiers_tagger", "mctiers"));
    private TierBadge() {}
    public static String glyph(String mode) {
        return switch (mode) {
            case "vanilla", "crystal" -> "\uf000";
            case "uhc" -> "\uf001";
            case "pot" -> "\uf002";
            case "nethop", "neth_op", "neth_pot" -> "\uf003";
            case "smp" -> "\uf004";
            case "sword" -> "\uf005";
            case "axe" -> "\uf006";
            case "mace" -> "\uf007";
            default -> FALLBACK_GLYPH;
        };
    }
    public static MutableText icon(String mode, String iconStyle) {
        String glyph = glyph(mode);
        StyleSpriteSource font = glyph.equals(FALLBACK_GLYPH) ? BADGE_FONT : "mctiers".equals(iconStyle) ? MCTIERS_FONT : CLASSIC_FONT;
        return Text.literal(glyph).setStyle(Style.EMPTY.withFont(font).withColor(0xFFFFFF)
                .withBold(false).withItalic(false));
    }
    public static int color(Ranking rank) {
        return paletteColor(rank, "mctiers");
    }
    private static int paletteColor(Ranking rank, String palette) {
        if (rank.retired()) return 0x8FB6DC;
        if ("pvptiers".equals(palette)) return switch (rank.displayTier()) {
            case 1 -> 0xF5CE4D;
            case 2 -> 0xBFCDD6;
            case 3 -> 0xB06453;
            case 4 -> 0xA0323D;
            default -> 0xBCBBC1;
        };
        boolean high = rank.displayPos() == 0;
        return switch (rank.displayTier()) {
            case 1 -> high ? 0xE8BA3A : 0xD5B355;
            case 2 -> high ? 0xC4D3E7 : 0xA0A7B2;
            case 3 -> high ? 0xF89F5A : 0xC67B42;
            case 4 -> high ? 0x81749A : 0x655B79;
            default -> high ? 0x8F82A8 : 0x655B79;
        };
    }
    public static String colorKey(Ranking rank) { return rank.retired() ? "RETIRED" : rank.label(); }
    public static int color(Ranking rank, TaggerConfig config) {
        return config.tierColors.getOrDefault(colorKey(rank), paletteColor(rank, config.tierPalette));
    }
    public static MutableText tier(Ranking rank, TaggerConfig config) {
        return Text.literal((rank.retired() ? "R" : "") + rank.label())
                .setStyle(Style.EMPTY.withFont(StyleSpriteSource.DEFAULT).withColor(color(rank, config))
                        .withBold(false).withItalic(false));
    }
    public static MutableText label(String mode, Ranking rank, TaggerConfig config) {
        MutableText text = Text.empty();
        if (config.showIcon) text.append(icon(mode, config.iconStyle)).append(" ");
        return text.append(tier(rank, config));
    }
    public static MutableText decorate(Text original, Ranking rank, String mode, TaggerConfig config) {
        MutableText badge = label(mode, rank, config);
        return Text.empty().append(badge).append(" ").append(original.copy());
    }
}
