package dev.mctierstag.ui;

import dev.mctierstag.MCTiersTagger;
import dev.mctierstag.api.PlayerProfile.Ranking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.text.Text;

public final class TierColorsScreen extends Screen {
    private final Screen parent;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private String status = "";
    public TierColorsScreen(Screen parent) { super(Text.literal("Tier colors")); this.parent = parent; }
    @Override protected void init() {
        int w = Math.min(300, width - 24), x = (width - w) / 2, half = (w - 8) / 2;
        var palette = addDrawableChild(ButtonWidget.builder(Text.literal("Palette: " + (mod.config.tierPalette.equals("pvptiers") ? "PvPTiers" : "MCTiers")), b -> {
            mod.config.tierPalette = mod.config.tierPalette.equals("mctiers") ? "pvptiers" : "mctiers";
            mod.config.tierColors.clear(); status = mod.save() ? "" : "Could not save colors."; clearAndInit();
        }).dimensions(x, 36, w, 20).build());
        palette.setTooltip(Tooltip.of(Text.literal("Apply the other original palette and reset custom colors")));
        for (int tier = 1; tier <= 5; tier++) for (int pos = 0; pos <= 1; pos++) {
            var rank = new Ranking(tier, pos, null, null, false);
            int color = TierBadge.color(rank, mod.config);
            addDrawableChild(ButtonWidget.builder(Text.literal(rank.label() + "  #" + String.format("%06X", color)).withColor(color),
                    b -> client.setScreen(new TierColorScreen(this, rank)))
                    .dimensions(x + pos * (half + 8), 62 + (tier - 1) * 22, half, 20).build());
        }
        var retired = new Ranking(2, 1, 2, 1, true);
        int retiredColor = TierBadge.color(retired, mod.config);
        addDrawableChild(ButtonWidget.builder(Text.literal("Retired  #" + String.format("%06X", retiredColor)).withColor(retiredColor),
                b -> client.setScreen(new TierColorScreen(this, retired))).dimensions(x, 172, w, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset all colors"), b -> {
            mod.config.tierColors.clear(); status = mod.save() ? "" : "Could not save colors."; clearAndInit();
        }).dimensions(x, height - 32, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(x + half + 8, height - 32, half, 20).build());
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, status.isEmpty() ? title : Text.literal(status), width / 2, 14, status.isEmpty() ? 0xFF75D8FF : 0xFFFF7777);
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
