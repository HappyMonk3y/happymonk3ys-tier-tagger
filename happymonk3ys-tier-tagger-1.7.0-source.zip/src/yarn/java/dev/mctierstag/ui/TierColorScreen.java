package dev.mctierstag.ui;

import dev.mctierstag.MCTiersTagger;
import dev.mctierstag.api.PlayerProfile.Ranking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.*;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.function.BooleanSupplier;

public final class TierColorScreen extends Screen {
    private static final int[] COLORS = {0xFFFFFF,0xABB3C0,0xFF5555,0xFFAA00,0xFFDB6E,0x55FF55,0x55FFFF,0x5599FF,
            0xAA55FF,0xFF55FF,0xFF88BB,0xB47B42,0xD39B62,0x5DB76B,0x555555,0x171717};
    private static final String[] NAMES = {"White","Silver","Red","Orange","Gold","Green","Cyan","Blue",
            "Purple","Magenta","Pink","Bronze","Copper","Forest","Gray","Black"};
    private final Screen parent;
    private final Ranking rank;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private TextFieldWidget hex;
    private ButtonWidget apply;
    private String status = "Choose a swatch or enter #RRGGBB";
    public TierColorScreen(Screen parent, Ranking rank) { super(Text.literal((rank.retired() ? "Retired" : rank.label()) + " color")); this.parent = parent; this.rank = rank; }
    private int savedColor() { return TierBadge.color(rank, mod.config); }
    private boolean validHex() { return hex.getText().matches("#?[A-Fa-f0-9]{6}"); }
    private int draftColor() { return validHex() ? Integer.parseInt(hex.getText().replace("#", ""), 16) : savedColor(); }
    @Override protected void init() {
        int w = Math.min(300, width - 24), x = (width - w) / 2, cell = (w - 42) / 8;
        for (int i = 0; i < COLORS.length; i++) {
            int color = COLORS[i];
            addDrawableChild(new Swatch(x + (i % 8) * (cell + 6), 90 + (i / 8) * 28, cell, color, NAMES[i],
                    b -> setColor(color), () -> savedColor() == color));
        }
        hex = new TextFieldWidget(textRenderer, x, 158, w - 84, 20, Text.literal("Hex color"));
        hex.setMaxLength(7); hex.setText(String.format("#%06X", savedColor())); addDrawableChild(hex);
        apply = addDrawableChild(ButtonWidget.builder(Text.literal("Apply"), b -> { if (validHex()) setColor(draftColor()); })
                .dimensions(x + w - 76, 158, 76, 20).build());
        hex.setChangedListener(value -> { apply.active = validHex(); status = validHex() ? "Press Apply to save this color" : "Enter six hex digits, e.g. #55FFFF"; });
        int half = (w - 8) / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset color"), b -> {
            mod.config.tierColors.remove(TierBadge.colorKey(rank)); hex.setText(String.format("#%06X", savedColor()));
            status = mod.save() ? "Default color restored" : "Could not save color.";
        }).dimensions(x, height - 32, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(x + half + 8, height - 32, half, 20).build());
    }
    private void setColor(int color) {
        mod.config.tierColors.put(TierBadge.colorKey(rank), color); hex.setText(String.format("#%06X", color));
        status = mod.save() ? "Color saved" : "Could not save color.";
    }
    @Override public boolean keyPressed(KeyInput input) {
        if (hex.isFocused() && (input.key() == GLFW.GLFW_KEY_ENTER || input.key() == GLFW.GLFW_KEY_KP_ENTER)) {
            if (validHex()) setColor(draftColor()); return true;
        }
        return super.keyPressed(input);
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 22, 0xFF75D8FF);
        var preview = Text.empty();
        if (mod.config.showIcon) preview.append(TierBadge.icon("vanilla", mod.config.iconStyle)).append(" ");
        preview.append(Text.literal((rank.retired() ? "R" : "") + rank.label()).withColor(draftColor())).append(Text.literal(" PlayerName").withColor(0xFFFFFF));
        context.drawCenteredTextWithShadow(textRenderer, preview, width / 2, 58, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, status, width / 2, height - 50, 0xFFAAAAAA);
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
    private static final class Swatch extends ButtonWidget {
        private final int color;
        private final BooleanSupplier selected;
        Swatch(int x, int y, int w, int color, String name, PressAction action, BooleanSupplier selected) {
            super(x, y, w, 22, net.minecraft.text.Text.literal(name), action, DEFAULT_NARRATION_SUPPLIER);
            this.color = color; this.selected = selected;
            setTooltip(Tooltip.of(net.minecraft.text.Text.literal(name + "  #" + String.format("%06X", color))));
        }
        @Override protected void drawIcon(DrawContext context, int mouseX, int mouseY, float delta) {
            int border = isHovered() || isFocused() || selected.getAsBoolean() ? 0xFFFFFFFF : 0xFF505866;
            context.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), border);
            context.fill(getX() + 2, getY() + 2, getX() + getWidth() - 2, getY() + getHeight() - 2, 0xFF000000 | color);
            if (selected.getAsBoolean()) {
                context.fill(getX() + getWidth() / 2 - 2, getY() + 8, getX() + getWidth() / 2 + 2, getY() + 14, 0xFF000000);
                context.fill(getX() + getWidth() / 2 - 1, getY() + 9, getX() + getWidth() / 2 + 1, getY() + 13, 0xFFFFFFFF);
            }
        }
    }
}
