package dev.mctierstag.api;
import java.util.concurrent.TimeUnit;
public final class LiveVerification {
    public static void main(String[] args) throws Exception {
        try (var api = new MCTiersApi()) {
            var result = api.lookupName("uku3lig").get(20, TimeUnit.SECONDS);
            if (result.profile() == null) throw new AssertionError(result.message());
            System.out.println("Live v2 name lookup: " + result.profile().name() + " " + result.profile().rankings());
            api.clearCache();
            var byUuid = api.lookup(result.profile().uuid()).get(20, TimeUnit.SECONDS);
            if (byUuid.profile() == null) throw new AssertionError(byUuid.message());
            System.out.println("Live v2 UUID lookup: PASS");
        }
    }
}
