package dev.mctierstag.mixin;

import dev.mctierstag.MCTiersTagger;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.Avatar;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class PlayerRendererMixin {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V", at = @At("RETURN"))
    private void mctiers$addTier(Avatar entity, AvatarRenderState state, float tickDelta, CallbackInfo ci) {
        // Only decorate real player labels that vanilla already permits (not mannequin entities).
        if (entity instanceof AbstractClientPlayer player && state.nameTag != null && MCTiersTagger.get() != null)
            state.nameTag = MCTiersTagger.get().decorate(entity.getUUID(), player.getGameProfile().name(), state.nameTag, false);
    }
}
