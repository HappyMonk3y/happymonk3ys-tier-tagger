package dev.mctierstag.mixin;

import dev.mctierstag.MCTiersTagger;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerListMixin {
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void mctiers$addTier(PlayerInfo entry, CallbackInfoReturnable<Component> cir) {
        if (MCTiersTagger.get() != null)
            cir.setReturnValue(MCTiersTagger.get().decorate(entry.getProfile().id(), entry.getProfile().name(), cir.getReturnValue(), true));
    }
}
