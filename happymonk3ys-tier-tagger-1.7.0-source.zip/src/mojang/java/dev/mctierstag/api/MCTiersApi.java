package dev.mctierstag.api;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.LongSupplier;

/** All HTTP and parsing runs outside Minecraft's render thread. No API key is needed. */
public final class MCTiersApi implements AutoCloseable {
    public static final String BASE_URL = "https://mctiers.net/api/v2/";
    public enum Status { FOUND, NOT_FOUND, ERROR }
    public record Result(Status status, PlayerProfile profile, String message) {
        static Result error(String message) { return new Result(Status.ERROR, null, message); }
    }
    private record Cached(Result result, long expires) {}
    private record Job(String key, String path, CompletableFuture<Result> future) {}
    private final URI base;
    private final HttpClient http;
    private final LongSupplier clock;
    private final long spacing;
    private final LinkedBlockingDeque<Job> queue = new LinkedBlockingDeque<>(256);
    private final Map<String, CompletableFuture<Result>> pending = new HashMap<>();
    private final LinkedHashMap<String, Cached> cache = new LinkedHashMap<>(128, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Cached> eldest) { return size() > 2048; }
    };
    private final Thread worker;
    private volatile boolean closed;
    private volatile long nextAllowed;
    private volatile Map<String, String> modes = defaultModes();
    private volatile boolean modesLoaded;

    public MCTiersApi() { this(URI.create(BASE_URL), 1000, System::currentTimeMillis); }
    MCTiersApi(URI base, long spacing, LongSupplier clock) {
        this.base = base;
        this.spacing = spacing;
        this.clock = clock;
        http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5))
                .followRedirects(HttpClient.Redirect.NEVER).build();
        worker = Thread.ofPlatform().daemon().name("MCTiers-API").start(this::work);
    }

    public CompletableFuture<Result> lookup(UUID uuid) { return request(uuid.toString(), "profile/" + uuid, false); }
    public CompletableFuture<Result> lookupName(String name) { return lookupName(name, true); }
    private CompletableFuture<Result> lookupName(String name, boolean priority) {
        if (name == null || !name.matches("[A-Za-z0-9_]{1,16}"))
            return CompletableFuture.completedFuture(Result.error("Use a Java username (1-16 letters, digits or _)."));
        return request("name:" + name.toLowerCase(Locale.ROOT), "profile/by-name/" + name, priority);
    }
    public CompletableFuture<Result> lookupPlayer(UUID uuid, String name) {
        // Offline-mode servers assign different UUIDs. The game-profile username is shared
        // by tab and world entities, and shares the same cache as explicit /tiers searches.
        return name != null && name.matches("[A-Za-z0-9_]{1,16}") ? lookupName(name, false) : lookup(uuid);
    }
    public PlayerProfile cachedOrRequest(UUID uuid, String name) {
        return lookupPlayer(uuid, name).getNow(new Result(Status.ERROR, null, "Loading")).profile();
    }
    private synchronized CompletableFuture<Result> request(String key, String path, boolean priority) {
        if (closed) return CompletableFuture.completedFuture(Result.error("Client is shutting down."));
        Cached found = cache.get(key);
        if (found != null && found.expires > clock.getAsLong()) return CompletableFuture.completedFuture(found.result);
        if (pending.containsKey(key)) return pending.get(key);
        CompletableFuture<Result> future = new CompletableFuture<>();
        Job job = new Job(key, path, future);
        pending.put(key, future);
        if (!(priority ? queue.offerFirst(job) : queue.offerLast(job))) {
            pending.remove(key);
            future.complete(Result.error("Lookup queue is full; try again shortly."));
        }
        return future;
    }

    private void work() {
        while (!closed) {
            Job job = null;
            try {
                job = queue.takeFirst();
                long wait = nextAllowed - clock.getAsLong();
                if (wait > 0) Thread.sleep(wait);
                HttpResponse<String> response = http.send(httpRequest(job.path), HttpResponse.BodyHandlers.ofString());
                Result result = decode(response.statusCode(), response.body());
                if (response.statusCode() == 429)
                    nextAllowed = clock.getAsLong() + retryDelay(response.headers().firstValue("Retry-After").orElse("60"));
                nextAllowed = Math.max(nextAllowed, clock.getAsLong() + spacing);
                if (result.profile != null && !job.key.startsWith("name:")
                        && !result.profile.uuid().toString().equals(job.key))
                    result = Result.error("API returned a different player UUID.");
                if (result.profile != null && job.key.startsWith("name:")
                        && !result.profile.name().equalsIgnoreCase(job.key.substring(5)))
                    result = Result.error("API returned a different player name.");
                finish(job, result);
            } catch (InterruptedException e) {
                if (job != null) finish(job, Result.error("Lookup cancelled."));
                if (closed) break;
            } catch (Exception e) {
                nextAllowed = clock.getAsLong() + Math.max(spacing, 5000);
                if (job != null) finish(job, Result.error("Cannot reach MCTiers. Try again shortly."));
            }
        }
    }
    private synchronized void finish(Job job, Result result) {
        long ttl = switch (result.status) { case FOUND -> 900_000; case NOT_FOUND -> 300_000; case ERROR -> 60_000; };
        Cached value = new Cached(result, clock.getAsLong() + ttl);
        cache.put(job.key, value);
        if (result.profile != null) {
            cache.put(result.profile.uuid().toString(), value);
            cache.put("name:" + result.profile.name().toLowerCase(Locale.ROOT), value);
        }
        pending.remove(job.key);
        job.future.complete(result);
    }
    private HttpRequest httpRequest(String path) {
        return HttpRequest.newBuilder(base.resolve(path)).timeout(Duration.ofSeconds(8))
                .header("Accept", "application/json").header("User-Agent", "HappyMonk3yTierTagger/1.7.0 (Fabric 1.21.11)")
                .GET().build();
    }
    static Result decode(int status, String body) {
        if (status == 404) return new Result(Status.NOT_FOUND, null, "No MCTiers profile found.");
        if (status == 429) return Result.error("MCTiers rate limit reached. Retrying after a cooldown.");
        if (status != 200) return Result.error("MCTiers returned HTTP " + status + ". Try again shortly.");
        if (body.length() > 1_000_000) return Result.error("MCTiers response is too large.");
        try { return new Result(Status.FOUND, PlayerProfile.parse(body), ""); }
        catch (RuntimeException e) { return Result.error("MCTiers returned an invalid v2 profile."); }
    }
    static long retryDelay(String value) {
        try { return Math.clamp(Long.parseLong(value), 1, 3600) * 1000; }
        catch (RuntimeException ignored) {
            try { return Math.clamp(Duration.between(java.time.Instant.now(),
                    ZonedDateTime.parse(value, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant()).toMillis(), 1000, 3_600_000); }
            catch (RuntimeException e) { return 60_000; }
        }
    }

    public Map<String, String> modes() { return modes; }
    public String modeTitle(String slug) { return "highest".equals(slug) ? "Highest tier" : "vanilla".equals(slug) ? "Crystal" : modes.getOrDefault(slug, slug); }
    public synchronized void loadModes() {
        if (modesLoaded || closed) return;
        modesLoaded = true;
        http.sendAsync(httpRequest("mode/list"), HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() != 200 || response.body().length() > 100_000) return;
                    try {
                        Map<String, String> updated = new TreeMap<>();
                        for (var e : JsonParser.parseString(response.body()).getAsJsonObject().entrySet()) {
                            if (!e.getKey().matches("[a-z0-9_\\-]{1,32}")) continue;
                            String title = e.getValue().getAsJsonObject().get("title").getAsString();
                            if (!title.isBlank() && title.length() <= 40 && title.chars().noneMatch(Character::isISOControl))
                                updated.put(e.getKey(), title);
                        }
                        if (!updated.isEmpty()) modes = Collections.unmodifiableMap(updated);
                    } catch (RuntimeException ignored) { /* The documented mode names remain available offline. */ }
                }).exceptionally(error -> null);
    }
    public synchronized void clearCache() { cache.clear(); }
    public synchronized int cachedCount() { return cache.size(); }
    public int queuedCount() { return queue.size(); }
    @Override public synchronized void close() {
        closed = true;
        worker.interrupt();
        queue.clear();
        pending.values().forEach(f -> f.complete(Result.error("Client is shutting down.")));
        pending.clear();
        http.shutdownNow();
    }
    private static Map<String, String> defaultModes() {
        return Collections.unmodifiableMap(new TreeMap<>(Map.of("axe", "Axe", "sword", "Sword", "vanilla", "Vanilla",
                "nethop", "NethPot", "pot", "Pot", "smp", "SMP", "uhc", "UHC", "mace", "Mace")));
    }
}
