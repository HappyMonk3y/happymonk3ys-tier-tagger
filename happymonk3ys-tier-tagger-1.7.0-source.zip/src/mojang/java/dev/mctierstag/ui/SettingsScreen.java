package dev.mctierstag.ui;

import dev.mctierstag.*;
import dev.mctierstag.api.PlayerProfile.Ranking;
import com.mojang.blaze3d.platform.InputConstants;
import java.util.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

public final class SettingsScreen extends Screen {
    private final Screen parent;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private String status = "";
    private String searchValue = "";
    private EditBox search;
    private int left, panelWidth, optionsY, searchY;
    public SettingsScreen(Screen parent) { super(Component.literal(MCTiersTagger.NAME)); this.parent = parent; }
    @Override protected void init() {
        mod.api.loadModes();
        panelWidth = Math.min(320, width - 24); left = (width - panelWidth) / 2;
        int half = (panelWidth - 8) / 2;
        optionsY = Math.max(100, height / 2 - 32);
        TaggerConfig c = mod.config;
        addRenderableWidget(Button.builder(Component.literal("Icons: " + c.iconChoiceLabel()), b -> {
            c.cycleIcons(); b.setMessage(Component.literal("Icons: " + c.iconChoiceLabel())); persist();
        }).bounds(left, optionsY + 14, half, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Tier colors..."), b -> minecraft.setScreen(new TierColorsScreen(this)))
                .bounds(left + half + 8, optionsY + 14, half, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Mode: " + mod.api.modeTitle(c.mode)), b -> {
            List<String> modes = new ArrayList<>(); modes.add("highest"); modes.addAll(mod.api.modes().keySet());
            c.mode = modes.get((modes.indexOf(c.mode) + 1) % modes.size());
            b.setMessage(Component.literal("Mode: " + mod.api.modeTitle(c.mode))); persist();
        }).bounds(left, optionsY + 42, half, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Tags: " + (c.enabled ? "ON" : "OFF")), b -> {
            c.enabled = !c.enabled; b.setMessage(Component.literal("Tags: " + (c.enabled ? "ON" : "OFF"))); persist();
        }).bounds(left + half + 8, optionsY + 42, half, 20).build());
        searchY = Math.min(optionsY + 76, height - 68);
        search = new EditBox(font, left, searchY, panelWidth - 84, 20, Component.literal("Minecraft username"));
        search.setMaxLength(16); search.setHint(Component.literal("Search player..."));
        search.setValue(searchValue); search.setResponder(value -> searchValue = value); addRenderableWidget(search);
        addRenderableWidget(Button.builder(Component.literal("Search"), b -> lookup())
                .bounds(left + panelWidth - 76, searchY, 76, 20).build());
        addRenderableWidget(Button.builder(Component.literal("More options..."), b -> minecraft.setScreen(new ExtraOptionsScreen(this)))
                .bounds(left, height - 32, half, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(left + half + 8, height - 32, half, 20).build());
    }
    private void persist() { if (!mod.save()) status = "Could not save settings; check the Minecraft log."; }
    private void lookup() {
        String name = search.getValue().trim();
        if (!name.matches("[A-Za-z0-9_]{1,16}")) { status = "Enter a valid Minecraft username."; return; }
        status = "";
        minecraft.setScreen(new ProfileScreen(this, name));
    }
    @Override public boolean keyPressed(KeyEvent input) {
        if (search.isFocused() && (input.key() == InputConstants.KEY_RETURN || input.key() == InputConstants.KEY_NUMPADENTER)) {
            lookup(); return true;
        }
        return super.keyPressed(input);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);
        context.centeredText(font, title, width / 2, 22, 0xFF75D8FF);
        context.fill(left, 50, left + panelWidth, 88, 0x70313A49);
        context.centeredText(font, "Preview", width / 2, 56, 0xFFAAAAAA);
        String mode = mod.config.mode.equals("highest") ? "vanilla" : mod.config.mode;
        Component preview = TierBadge.decorate(Component.literal("PlayerName"), new Ranking(3, 1, null, null, false), mode, mod.config);
        context.centeredText(font, preview, width / 2, 72, 0xFFFFFFFF);
        context.text(font, "Options", left, optionsY, 0xFFBBBBBB);
        context.centeredText(font, font.plainSubstrByWidth(status, width - 16), width / 2, searchY + 23, 0xFFAAAAAA);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
