package dev.mctierstag.ui;

import dev.mctierstag.*;
import java.util.function.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ExtraOptionsScreen extends Screen {
    private final Screen parent;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private String status = "";
    public ExtraOptionsScreen(Screen parent) { super(Component.literal("More options")); this.parent = parent; }
    @Override protected void init() {
        int w = Math.min(280, width - 24), x = (width - w) / 2;
        var c = mod.config;
        toggle(x, 62, w, "Tab list", () -> c.tabList, v -> c.tabList = v);
        toggle(x, 90, w, "Highest-tier fallback", () -> c.fallback, v -> c.fallback = v);
        toggle(x, 118, w, "Show retired tiers", () -> c.includeRetired, v -> c.includeRetired = v);
        addRenderableWidget(Button.builder(Component.literal("Refresh tiers"), b -> {
            mod.api.clearCache(); status = "Player tiers will reload.";
        }).bounds(x, 152, w, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(x, height - 32, w, 20).build());
    }
    private void toggle(int x, int y, int w, String label, BooleanSupplier getter, Consumer<Boolean> setter) {
        addRenderableWidget(Button.builder(Component.literal(label + ": " + (getter.getAsBoolean() ? "ON" : "OFF")), b -> {
            setter.accept(!getter.getAsBoolean()); b.setMessage(Component.literal(label + ": " + (getter.getAsBoolean() ? "ON" : "OFF")));
            if (!mod.save()) status = "Could not save settings.";
        }).bounds(x, y, w, 20).build());
    }
    @Override public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);
        context.centeredText(font, title, width / 2, 22, 0xFF75D8FF);
        context.centeredText(font, status, width / 2, height - 50, 0xFFAAAAAA);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
