package dev.mctierstag.ui;

import dev.mctierstag.*;
import dev.mctierstag.api.*;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.*;

public final class ProfileScreen extends Screen {
    private final Screen parent;
    private final String name;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private MCTiersApi.Result result;
    private int page;
    private long requestNumber;
    public ProfileScreen(Screen parent, String name) { super(Component.literal(MCTiersTagger.NAME)); this.parent = parent; this.name = name; }
    @Override protected void init() {
        addRenderableWidget(Button.builder(Component.literal("<"), b -> page = Math.max(0, page - 1))
                .bounds(width / 2 - 148, height - 28, 28, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(width / 2 - 116, height - 28, 112, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Refresh"), b -> { mod.api.clearCache(); fetch(); })
                .bounds(width / 2 + 4, height - 28, 112, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            if ((page + 1) * rowsPerPage() < allModes().size()) page++;
        }).bounds(width / 2 + 120, height - 28, 28, 20).build());
        if (result == null) fetch();
    }
    private void fetch() {
        mod.api.loadModes();
        result = null; page = 0;
        long request = ++requestNumber;
        if (LocalTierOverrides.appliesTo(name)) return;
        mod.api.lookupName(name).thenAccept(value -> minecraft.execute(() -> { if (request == requestNumber) result = value; }));
    }
    private Map<String, PlayerProfile.Ranking> displayedRankings() {
        if (LocalTierOverrides.appliesTo(name)) return LocalTierOverrides.rankings(mod.api.modes().keySet());
        return result != null && result.profile() != null ? result.profile().rankings() : Map.of();
    }
    private int rowsPerPage() { return Math.max(1, (height - 120) / 18); }
    private List<String> allModes() {
        Set<String> modes = new TreeSet<>(mod.api.modes().keySet());
        modes.addAll(displayedRankings().keySet());
        return new ArrayList<>(modes);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);
        context.centeredText(font, title, width / 2, 16, 0xFF75D8FF);
        boolean custom = LocalTierOverrides.appliesTo(name);
        if (!custom && (result == null || result.profile() == null)) {
            String message = result == null ? "Looking up " + name + "..." : result.message();
            context.textWithWordWrap(font, Component.literal(message), Math.max(10, width / 2 - 150), 62,
                    Math.min(300, width - 20), 0xFFCCCCCC);
            return;
        }
        if (custom) {
            context.centeredText(font, LocalTierOverrides.PLAYER, width / 2, 36, 0xFFFFFFFF);
            context.centeredText(font, "Custom display tiers", width / 2, 50, 0xFFAAAAAA);
        } else {
            PlayerProfile profile = result.profile();
            context.centeredText(font, profile.name() + "  |  " + profile.region(), width / 2, 36, 0xFFFFFFFF);
            context.centeredText(font, "Overall " + (profile.overall() > 0 ? "#" + profile.overall() : "unranked")
                    + "  |  " + profile.points() + " points", width / 2, 50, 0xFFAAAAAA);
        }
        var displayed = displayedRankings();
        var rankings = allModes();
        int perPage = rowsPerPage();
        int maxPage = Math.max(0, (rankings.size() - 1) / perPage);
        page = Math.min(page, maxPage);
        int w = Math.min(360, width - 20), x = (width - w) / 2;
        for (int i = page * perPage; i < Math.min(rankings.size(), (page + 1) * perPage); i++) {
            String mode = rankings.get(i); var rank = displayed.get(mode); int y = 72 + (i % perPage) * 18;
            context.fill(x, y - 3, x + w, y + 13, 0xA0202430);
            MutableComponent line = Component.empty();
            if (mod.config.showIcon) line.append(TierBadge.icon(mode, mod.config.iconStyle)).append(" ");
            line.append(Component.literal(mod.api.modeTitle(mode) + "  ").withStyle(ChatFormatting.WHITE));
            if (rank == null) line.append(Component.literal("Unranked").withColor(0xC2C7D2));
            else {
                line.append(TierBadge.tier(rank, mod.config));
                if (!custom) line.append(Component.literal("   Peak " + rank.peakLabel()).withStyle(ChatFormatting.GRAY));
                if (rank.retired()) line.append(Component.literal("   retired").withStyle(ChatFormatting.GRAY));
            }
            context.text(font, line, x + 7, y, 0xFFFFFFFF);
        }
        if (rankings.isEmpty()) context.centeredText(font, "No ranked gamemodes.", width / 2, 82, 0xFFAAAAAA);
        context.centeredText(font, "R = retired  |  " + (page + 1) + "/" + (maxPage + 1),
                width / 2, height - 43, 0xFFAAAAAA);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
