package dev.mctierstag.ui;

import dev.mctierstag.MCTiersTagger;
import dev.mctierstag.api.PlayerProfile.Ranking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;

import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;
import java.util.function.BooleanSupplier;

public final class TierColorScreen extends Screen {
    private static final int[] COLORS = {0xFFFFFF,0xABB3C0,0xFF5555,0xFFAA00,0xFFDB6E,0x55FF55,0x55FFFF,0x5599FF,
            0xAA55FF,0xFF55FF,0xFF88BB,0xB47B42,0xD39B62,0x5DB76B,0x555555,0x171717};
    private static final String[] NAMES = {"White","Silver","Red","Orange","Gold","Green","Cyan","Blue",
            "Purple","Magenta","Pink","Bronze","Copper","Forest","Gray","Black"};
    private final Screen parent;
    private final Ranking rank;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private EditBox hex;
    private Button apply;
    private String status = "Choose a swatch or enter #RRGGBB";
    public TierColorScreen(Screen parent, Ranking rank) { super(Component.literal((rank.retired() ? "Retired" : rank.label()) + " color")); this.parent = parent; this.rank = rank; }
    private int savedColor() { return TierBadge.color(rank, mod.config); }
    private boolean validHex() { return hex.getValue().matches("#?[A-Fa-f0-9]{6}"); }
    private int draftColor() { return validHex() ? Integer.parseInt(hex.getValue().replace("#", ""), 16) : savedColor(); }
    @Override protected void init() {
        int w = Math.min(300, width - 24), x = (width - w) / 2, cell = (w - 42) / 8;
        for (int i = 0; i < COLORS.length; i++) {
            int color = COLORS[i];
            addRenderableWidget(new Swatch(x + (i % 8) * (cell + 6), 90 + (i / 8) * 28, cell, color, NAMES[i],
                    b -> setColor(color), () -> savedColor() == color));
        }
        hex = new EditBox(font, x, 158, w - 84, 20, Component.literal("Hex color"));
        hex.setMaxLength(7); hex.setValue(String.format("#%06X", savedColor())); addRenderableWidget(hex);
        apply = addRenderableWidget(Button.builder(Component.literal("Apply"), b -> { if (validHex()) setColor(draftColor()); })
                .bounds(x + w - 76, 158, 76, 20).build());
        hex.setResponder(value -> { apply.active = validHex(); status = validHex() ? "Press Apply to save this color" : "Enter six hex digits, e.g. #55FFFF"; });
        int half = (w - 8) / 2;
        addRenderableWidget(Button.builder(Component.literal("Reset color"), b -> {
            mod.config.tierColors.remove(TierBadge.colorKey(rank)); hex.setValue(String.format("#%06X", savedColor()));
            status = mod.save() ? "Default color restored" : "Could not save color.";
        }).bounds(x, height - 32, half, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(x + half + 8, height - 32, half, 20).build());
    }
    private void setColor(int color) {
        mod.config.tierColors.put(TierBadge.colorKey(rank), color); hex.setValue(String.format("#%06X", color));
        status = mod.save() ? "Color saved" : "Could not save color.";
    }
    @Override public boolean keyPressed(KeyEvent input) {
        if (hex.isFocused() && (input.key() == InputConstants.KEY_RETURN || input.key() == InputConstants.KEY_NUMPADENTER)) {
            if (validHex()) setColor(draftColor()); return true;
        }
        return super.keyPressed(input);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);
        context.centeredText(font, title, width / 2, 22, 0xFF75D8FF);
        var preview = Component.empty();
        if (mod.config.showIcon) preview.append(TierBadge.icon("vanilla", mod.config.iconStyle)).append(" ");
        preview.append(Component.literal((rank.retired() ? "R" : "") + rank.label()).withColor(draftColor())).append(Component.literal(" PlayerName").withColor(0xFFFFFF));
        context.centeredText(font, preview, width / 2, 58, 0xFFFFFFFF);
        context.centeredText(font, status, width / 2, height - 50, 0xFFAAAAAA);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
    private static final class Swatch extends Button {
        private final int color;
        private final BooleanSupplier selected;
        Swatch(int x, int y, int w, int color, String name, OnPress action, BooleanSupplier selected) {
            super(x, y, w, 22, net.minecraft.network.chat.Component.literal(name), action, DEFAULT_NARRATION);
            this.color = color; this.selected = selected;
            setTooltip(Tooltip.create(net.minecraft.network.chat.Component.literal(name + "  #" + String.format("%06X", color))));
        }
        @Override protected void extractContents(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
            int border = isHovered() || isFocused() || selected.getAsBoolean() ? 0xFFFFFFFF : 0xFF505866;
            context.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), border);
            context.fill(getX() + 2, getY() + 2, getX() + getWidth() - 2, getY() + getHeight() - 2, 0xFF000000 | color);
            if (selected.getAsBoolean()) {
                context.fill(getX() + getWidth() / 2 - 2, getY() + 8, getX() + getWidth() / 2 + 2, getY() + 14, 0xFF000000);
                context.fill(getX() + getWidth() / 2 - 1, getY() + 9, getX() + getWidth() / 2 + 1, getY() + 13, 0xFFFFFFFF);
            }
        }
    }
}
