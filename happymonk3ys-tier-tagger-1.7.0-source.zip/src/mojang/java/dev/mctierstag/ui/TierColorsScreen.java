package dev.mctierstag.ui;

import dev.mctierstag.MCTiersTagger;
import dev.mctierstag.api.PlayerProfile.Ranking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class TierColorsScreen extends Screen {
    private final Screen parent;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private String status = "";
    public TierColorsScreen(Screen parent) { super(Component.literal("Tier colors")); this.parent = parent; }
    @Override protected void init() {
        int w = Math.min(300, width - 24), x = (width - w) / 2, half = (w - 8) / 2;
        var palette = addRenderableWidget(Button.builder(Component.literal("Palette: " + (mod.config.tierPalette.equals("pvptiers") ? "PvPTiers" : "MCTiers")), b -> {
            mod.config.tierPalette = mod.config.tierPalette.equals("mctiers") ? "pvptiers" : "mctiers";
            mod.config.tierColors.clear(); status = mod.save() ? "" : "Could not save colors."; rebuildWidgets();
        }).bounds(x, 36, w, 20).build());
        palette.setTooltip(Tooltip.create(Component.literal("Apply the other original palette and reset custom colors")));
        for (int tier = 1; tier <= 5; tier++) for (int pos = 0; pos <= 1; pos++) {
            var rank = new Ranking(tier, pos, null, null, false);
            int color = TierBadge.color(rank, mod.config);
            addRenderableWidget(Button.builder(Component.literal(rank.label() + "  #" + String.format("%06X", color)).withColor(color),
                    b -> minecraft.setScreen(new TierColorScreen(this, rank)))
                    .bounds(x + pos * (half + 8), 62 + (tier - 1) * 22, half, 20).build());
        }
        var retired = new Ranking(2, 1, 2, 1, true);
        int retiredColor = TierBadge.color(retired, mod.config);
        addRenderableWidget(Button.builder(Component.literal("Retired  #" + String.format("%06X", retiredColor)).withColor(retiredColor),
                b -> minecraft.setScreen(new TierColorScreen(this, retired))).bounds(x, 172, w, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset all colors"), b -> {
            mod.config.tierColors.clear(); status = mod.save() ? "" : "Could not save colors."; rebuildWidgets();
        }).bounds(x, height - 32, half, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(x + half + 8, height - 32, half, 20).build());
    }
    @Override public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);
        context.centeredText(font, status.isEmpty() ? title : Component.literal(status), width / 2, 14, status.isEmpty() ? 0xFF75D8FF : 0xFFFF7777);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
