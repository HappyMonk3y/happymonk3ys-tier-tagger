package dev.mctierstag.integration;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import dev.mctierstag.ui.SettingsScreen;

public final class TaggerModMenu implements ModMenuApi {
    @Override public ConfigScreenFactory<SettingsScreen> getModConfigScreenFactory() {
        return SettingsScreen::new;
    }
}
