param([string[]]$Versions, [switch]$Smoke)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    $matrix = Get-Content -LiteralPath 'versions.json' -Raw | ConvertFrom-Json
    if (!$Versions) { $Versions = $matrix.PSObject.Properties.Name }
    New-Item -ItemType Directory -Force -Path 'build/matrix-logs' | Out-Null
    foreach ($mc in $Versions) {
        if (!$matrix.PSObject.Properties[$mc]) { throw "Unsupported version: $mc" }
        $taskArgs = @('build', "-Pmc=$mc", '--console=plain')
        if ($Smoke) { $taskArgs += 'runSmoke' }
        Write-Output "Building Minecraft $mc"
        & .\gradlew.bat @taskArgs *> "build/matrix-logs/$mc.log"
        if ($LASTEXITCODE -ne 0) {
            Get-Content -LiteralPath "build/matrix-logs/$mc.log" -Tail 90
            throw "Minecraft $mc failed; see build/matrix-logs/$mc.log"
        }
        Write-Output "PASS Minecraft $mc"
    }
} finally { Pop-Location }
