HappyMonk3y's Tier Tagger 1.6.0
Minecraft Java 1.21.11 / Fabric / Java 21

INSTALL / UPGRADE
1. Use Fabric Loader 0.18.4 or newer for Minecraft 1.21.11.
2. Install Fabric API for 1.21.11:
   https://modrinth.com/mod/fabric-api
3. Install Mod Menu for 1.21.11 (tested with 17.0.1):
   https://modrinth.com/mod/modmenu/version/17.0.1
4. Remove the previous version, original Tier Tagger and Tiers mod.
   Duplicate commands/name decoration conflict with this build.
5. Add happymonk3ys-tier-tagger-1.6.0+mc1.21.11.jar to the mods folder.
6. Restart Minecraft. No server installation is needed.

SIMPLER SETTINGS
Open Mods > HappyMonk3y's Tier Tagger > Configure.
The main screen has a live preview and four options:
- Icons, at the top left: Classic / MCTiers / Off.
- Tier colors: customize any HT1-LT5 color.
- Mode: select a gamemode or your highest tier.
- Tags: enable or disable tier tags.
The search field directly below these four options opens any player's
profile. Enter a username and click Search, or press Enter.
More options contains tab-list tags, highest-tier fallback, retired tiers
and cache refresh. The old Above names, Position, Mode label and Region
controls are removed. Tags always use the compact icon + tier + name
layout. The old /mctiers command and N keybind remain removed.

TIER COLORS
The default palette exactly matches the original MCTiers / Tier Tagger:
        HT         LT
Tier 1  #E8BA3A    #D5B355
Tier 2  #C4D3E7    #A0A7B2
Tier 3  #F89F5A    #C67B42
Tier 4  #81749A    #655B79
Tier 5  #8F82A8    #655B79
Retired tiers use the user-selected #8FB6DC in both palettes.
The Palette button switches between MCTiers and PvPTiers, applying the
original colors and resetting custom edits. PvPTiers is an alternate
preset; icon choice is independent of the tier-color palette.
Choose Tier colors, then the HT or LT tier you want to edit.
Click a color swatch to save instantly, or enter a six-digit hex color
such as #55FFFF and click Apply (or press Enter). Invalid hex cannot save.
The preview updates while entering a valid color.
Reset color restores that tier. Reset all colors restores every tier.
Colors apply to nametags, tab and /tiers profiles, and survive restarts.
The separate Retired entry customizes all retired ranks, including RLT2.
Changing an active tier's color does not change retired colors.

PLAYER SEARCH
/tiers <player>
Examples: /tiers HappyMonk3y
          /tiers uku3lig

Profiles show all gamemodes, including unranked modes. For API profiles,
they show current tiers, peaks, retired status, region, points and rank.
Small windows paginate using the arrows. The selected nametag gamemode
does not filter profile results. R before a tier means retired.
Crystal uses the API mode ID vanilla; NethPot uses nethop.

OFFLINE ACCOUNTS AND OVERHEAD TAGS
Automatic tags now match the player's game-profile username, ignoring
letter case, instead of requiring the server UUID to match the MCTiers
UUID. This supports offline/cracked servers and proxy-assigned UUIDs.
Tab, overhead names and searches share the same username cache, so a
cached tier remains available when the player teleports or reappears.
The lookup uses the real username sent by the server, not a formatted
nickname or scoreboard prefix. Missing/invalid names fall back to UUID.
Vanilla name visibility and distance rules are preserved.

HAPPYMONK3Y CUSTOM DISPLAY
This custom build locally displays HappyMonk3y as:
- Crystal: RLT2 (retired Low Tier 2)
- Every other gamemode: LT3
The match uses the exact game-profile username, ignoring letter case.
It applies to nametags, tab and /tiers HappyMonk3y, without waiting for an
API profile. Highest tier selects Crystal RLT2 when retired tiers are on.
Other players continue to use MCTiers API data normally.
This is a client-side cosmetic override, separate from the API cache.
It does not change the MCTiers website or what unmodified clients see.
The profile screen identifies these as Custom display tiers.

ICONS
Both eight-icon sets come unchanged from the Tiers resource pack:
Classic flat colored symbols and MCTiers outlined artwork.
They cover Crystal, UHC, Pot, NethPot, SMP, Sword, Axe and Mace.
Original 7-pixel font height/ascent is preserved. No extra pack is needed.
Unknown future modes use the original generic badge.
Off hides icons in tags, tab and profiles.

UPGRADING
The internal mod ID and config/mctiers-tagger.json path remain the same.
Existing icon choice, mode and remaining preferences are preserved.
Removed settings no longer change the compact display.
Upgrading from 1.5.x applies the new retired color once, keeping active-tier
colors, palette choice and other settings. Upgrades from before 1.5 also
apply the previously requested MCTiers palette. New edits remain saved.

API AND CACHING
Uses the supplied MCTiers v2.1.0 contract at https://mctiers.net/api/v2/:
  profile/{uuid}
  profile/by-name/{name}
  mode/list
The source includes docs/api-v2.json.
Automatic lookups send player usernames to mctiers.net, with UUID lookup
as a fallback when a valid username is unavailable. Explicit searches
send the entered Minecraft username, except the local override.
No credentials, chat contents, server addresses or telemetry are sent.
Only preferences are stored on disk; API responses stay in memory.
Background lookups use a bounded queue/cache and one-second spacing.
Positive results cache 15 minutes, missing profiles 5 minutes, failures
1 minute. HTTP 429 pauses requests according to Retry-After.
Malformed API responses never create tiers. The explicit HappyMonk3y
override is the only custom tier data in this build.

BUILD AND VERIFICATION
JDK 21 required. From the extracted source:
  Windows: gradlew.bat build
  Linux/macOS: sh gradlew build
Use the mod JAR in build/libs/, not a sources or gametest JAR.

Pinned dependencies: Gradle 9.6.0, Loom 1.15.5, Fabric Loader 0.18.4,
Fabric API 0.141.6+1.21.11, Yarn 1.21.11+build.6, Mod Menu 17.0.1.
Dependencies download on first build.

gradlew.bat verifyCore         69 deterministic API/selection/cache checks
gradlew.bat verifyLive         Optional live name and UUID API checks
gradlew.bat runClientGameTest  Isolated client integration checks

The client checks cover the simplified layout and search, both icon sets, Mod Menu,
color swatches, valid/invalid hex, persistence and reset, old preferences,
a small-window layout, /tiers, a live API profile, the tab-list mixin,
and HappyMonk3y's custom tiers for all gamemodes. Both presets are checked
against the upstream JSON files, including every HT/LT color. Retired
colors and palette migration/reset/persistence are also checked. The
world-render test creates remote players with offline UUIDs, checks the
actual overhead render state, moves a player out of range and back, and
verifies tab/overhead agreement and HappyMonk3y's retired color.
Tests use a disposable
local world. Screenshots: build/run/clientGameTest/screenshots/.
Test code is excluded from the installable JAR.
Not every multiplayer server/mod combination has been tested.

LICENSE / CREDITS
Classic and MCTiers textures: Tiers by Flavio6561 / PvPTiers and contributors.
https://modrinth.com/mod/tiers
https://github.com/PvPTiers/Tiers
Exact revision/files: THIRD_PARTY_NOTICES.txt.
The combined distribution is GPL-3.0-only; full license in LICENSE and
complete corresponding source supplied in the accompanying source ZIP.
Independently authored code and the original fallback/app icon also retain
their MIT terms in LICENSE-MIT.txt. No Tiers Java code is included.
Unofficial community mod; not an official MCTiers or Mojang release.
