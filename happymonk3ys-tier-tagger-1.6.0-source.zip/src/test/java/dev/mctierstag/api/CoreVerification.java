package dev.mctierstag.api;

import com.sun.net.httpserver.HttpServer;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Deterministic contract/integration checks; uses a loopback HTTP server, never the public service. */
public final class CoreVerification {
    private static final UUID ID = UUID.fromString("6553509f-66d3-4041-875f-164236e42e84");
    private static int checks;
    public static void main(String[] args) throws Exception {
        rankingRules();
        httpContract();
        System.out.println("PASS: " + checks + " MCTiers contract, selection and HTTP/cache checks");
    }
    private static void check(boolean value, String name) {
        checks++;
        if (!value) throw new AssertionError(name);
    }
    private static String profile(String rankings) {
        return "{\"uuid\":\"" + ID + "\",\"name\":\"uku3lig\",\"region\":\"EU\",\"overall\":123,\"points\":10,\"rankings\":" + rankings + "}";
    }
    private static void rankingRules() {
        var p = PlayerProfile.parse(profile("""
            {"sword":{"tier":3,"pos":1,"peak_tier":2,"peak_pos":0,"retired":false},
             "axe":{"tier":4,"pos":1,"peak_tier":1,"peak_pos":1,"retired":true},
             "nethop":{"tier":2,"pos":0,"retired":false}}
            """));
        check(p.rankings().get("sword").label().equals("LT3"), "active tier must not use peak");
        check(p.rankings().get("axe").label().equals("LT1"), "retired tier uses peak");
        check(p.select("highest", true, true).orElseThrow().mode().equals("axe"), "best retired peak included");
        check(p.select("highest", true, false).orElseThrow().mode().equals("nethop"), "retired excluded");
        check(p.select("sword", true, true).orElseThrow().mode().equals("sword"), "selected mode wins");
        check(p.select("mace", true, false).orElseThrow().mode().equals("nethop"), "highest fallback");
        check(p.select("mace", false, false).isEmpty(), "selected only has no fabricated rank");
        check(p.select("axe", false, false).isEmpty(), "hidden retired selection");
        check(new PlayerProfile.Ranking(5, 1, null, null, true).label().equals("LT5"), "null peak fallback");
        check(new PlayerProfile.Ranking(3, 0, 0, 5, true).label().equals("HT3"), "invalid peak fallback");
        check(PlayerProfile.parseUuid(ID.toString().replace("-", "")).equals(ID), "compact UUID");
        for (int tier = 1; tier <= 5; tier++) for (int pos = 0; pos <= 1; pos++) {
            var rank = new PlayerProfile.Ranking(tier, pos, null, null, false);
            check(rank.label().equals((pos == 0 ? "HT" : "LT") + tier), "tier label " + tier + "/" + pos);
            check(rank.strength() == (tier - 1) * 2 + pos, "tier ordering " + tier + "/" + pos);
        }
        check(PlayerProfile.parse(profile("{}")).rankings().isEmpty(), "unranked valid profile");
        check(MCTiersApi.decode(404, "").status() == MCTiersApi.Status.NOT_FOUND, "404 distinct from errors");
        check(MCTiersApi.decode(500, "{}").status() == MCTiersApi.Status.ERROR, "500 not unranked");
        check(MCTiersApi.decode(200, "<html>down</html>").status() == MCTiersApi.Status.ERROR, "HTML cannot become a tier");
        check(MCTiersApi.decode(200, "{\"uuid\":\"" + ID + "\",\"name\":\"uku3lig\"}").status() == MCTiersApi.Status.ERROR, "missing rankings rejected");
        check(MCTiersApi.decode(200, profile("{\"sword\":{\"tier\":1}}" )).status() == MCTiersApi.Status.ERROR, "missing pos never becomes HT1");
        check(MCTiersApi.decode(200, profile("{\"sword\":{\"tier\":1.5,\"pos\":0}}" )).status() == MCTiersApi.Status.ERROR, "fractional tiers rejected");
        check(PlayerProfile.parse(profile("{\"bad\":{},\"sword\":{\"tier\":3,\"pos\":0}}")).rankings().size() == 1, "malformed sibling isolated");
        check(MCTiersApi.retryDelay("2") == 2000, "Retry-After seconds");
        check(MCTiersApi.retryDelay("invalid") == 60000, "Retry-After fallback");
    }
    private static void httpContract() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        AtomicInteger hits = new AtomicInteger(), code = new AtomicInteger(200);
        AtomicReference<String> body = new AtomicReference<>(profile("{\"sword\":{\"tier\":3,\"pos\":0}}"));
        AtomicReference<String> path = new AtomicReference<>("");
        CountDownLatch arrived = new CountDownLatch(1), release = new CountDownLatch(1);
        server.createContext("/api/v2/profile/", exchange -> {
            path.set(exchange.getRequestURI().getPath());
            if (hits.incrementAndGet() == 1) {
                arrived.countDown();
                try { release.await(5, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
            if (code.get() == 429) exchange.getResponseHeaders().set("Retry-After", "1");
            byte[] bytes = body.get().getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(code.get(), bytes.length);
            try (var out = exchange.getResponseBody()) { out.write(bytes); }
        });
        server.createContext("/api/v2/mode/list", exchange -> {
            byte[] bytes = "{\"new_mode\":{\"title\":\"New Mode\"},\"nethop\":{\"title\":\"NethPot\"}}".getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, bytes.length);
            try (var out = exchange.getResponseBody()) { out.write(bytes); }
        });
        var executor = Executors.newVirtualThreadPerTaskExecutor();
        server.setExecutor(executor); server.start();
        AtomicLong now = new AtomicLong(System.currentTimeMillis());
        URI base = URI.create("http://localhost:" + server.getAddress().getPort() + "/api/v2/");
        try (MCTiersApi api = new MCTiersApi(base, 0, now::get)) {
            var first = api.lookup(ID);
            check(arrived.await(5, TimeUnit.SECONDS), "request starts on background worker");
            check(api.lookup(ID) == first, "in-flight lookups coalesce");
            release.countDown();
            check(first.get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.FOUND, "UUID lookup succeeds");
            check(path.get().equals("/api/v2/profile/" + ID), "v2 UUID endpoint");
            check(api.lookup(ID).get().profile() != null && hits.get() == 1, "cached UUID avoids network");
            check(api.lookupName("UKU3LIG").get().profile() != null && hits.get() == 1, "case-insensitive name alias");
            now.addAndGet(900_001);
            check(api.lookup(ID).get(5, TimeUnit.SECONDS).profile() != null && hits.get() == 2, "positive TTL expires");
            api.clearCache();
            check(api.lookupName("uku3lig").get(5, TimeUnit.SECONDS).profile() != null, "name lookup succeeds");
            check(path.get().equals("/api/v2/profile/by-name/uku3lig"), "v2 name endpoint");
            int before = hits.get();
            check(api.lookupName("../../bad").get().status() == MCTiersApi.Status.ERROR && hits.get() == before, "invalid name never requested");
            UUID offlineId = UUID.nameUUIDFromBytes("OfflinePlayer:uku3lig".getBytes(StandardCharsets.UTF_8));
            check(!offlineId.equals(ID), "offline identity differs from real UUID");
            check(api.lookupPlayer(offlineId, "UKU3LIG").get().profile().uuid().equals(ID) && hits.get() == before,
                    "offline player shares the name cache without a UUID request");
            api.clearCache();
            check(api.lookupPlayer(offlineId, "uku3lig").get(5, TimeUnit.SECONDS).profile().uuid().equals(ID), "offline lookup works with an empty cache");
            check(path.get().equals("/api/v2/profile/by-name/uku3lig"), "automatic lookup uses name endpoint");
            before = hits.get();
            check(api.cachedOrRequest(UUID.randomUUID(), "uku3lig") != null && hits.get() == before, "recreated world entity reuses name cache");
            check(api.lookupPlayer(ID, null).get().profile() != null, "missing name falls back to UUID");
            api.clearCache(); code.set(404);
            check(api.lookup(ID).get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.NOT_FOUND, "HTTP 404 handled");
            before = hits.get();
            api.lookup(ID).get(); check(hits.get() == before, "negative result cached");
            now.addAndGet(300_001); code.set(500);
            check(api.lookup(ID).get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.ERROR, "negative TTL expires");
            before = hits.get(); api.lookup(ID).get(); check(hits.get() == before, "errors have retry TTL");
            now.addAndGet(60_001); code.set(200); body.set("not json");
            check(api.lookup(ID).get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.ERROR, "invalid response does not kill worker");
            api.clearCache(); body.set(profile("{}"));
            check(api.lookup(ID).get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.FOUND, "worker recovers");
            var other = UUID.randomUUID();
            check(api.lookup(other).get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.ERROR, "wrong UUID rejected");
            check(api.lookupPlayer(other, "OtherName").get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.ERROR, "wrong username rejected");
            api.loadModes();
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
            while (!api.modes().containsKey("new_mode") && System.nanoTime() < deadline) Thread.sleep(10);
            check(api.modes().containsKey("new_mode") && api.modeTitle("nethop").equals("NethPot"), "dynamic mode IDs loaded");
        } finally { release.countDown(); server.stop(0); executor.close(); }

        // A separate real-clock instance checks that 429 pauses the queue, not just one player's cache.
        HttpServer rateServer = HttpServer.create(new InetSocketAddress("localhost", 0), 0);
        AtomicInteger rateHits = new AtomicInteger();
        rateServer.createContext("/", exchange -> {
            rateHits.incrementAndGet(); exchange.getResponseHeaders().set("Retry-After", "1");
            byte[] bytes = "{}".getBytes(StandardCharsets.UTF_8); exchange.sendResponseHeaders(429, bytes.length);
            try (var out = exchange.getResponseBody()) { out.write(bytes); }
        });
        rateServer.start();
        try (var api = new MCTiersApi(URI.create("http://localhost:" + rateServer.getAddress().getPort() + "/"), 0, System::currentTimeMillis)) {
            check(api.lookup(ID).get(5, TimeUnit.SECONDS).status() == MCTiersApi.Status.ERROR, "429 is an error");
            var waiting = api.lookup(UUID.randomUUID());
            Thread.sleep(150);
            check(rateHits.get() == 1 && !waiting.isDone(), "429 cooldown pauses all queued requests");
            waiting.get(5, TimeUnit.SECONDS);
            check(rateHits.get() == 2, "queue resumes after cooldown");
        } finally { rateServer.stop(0); }
    }
}
