package dev.mctierstag.mixin;

import dev.mctierstag.MCTiersTagger;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerRendererMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V", at = @At("RETURN"))
    private void mctiers$addTier(PlayerLikeEntity entity, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
        // Only decorate real player labels that vanilla already permits (not mannequin entities).
        if (entity instanceof AbstractClientPlayerEntity player && state.displayName != null && MCTiersTagger.get() != null)
            state.displayName = MCTiersTagger.get().decorate(entity.getUuid(), player.getGameProfile().name(), state.displayName, false);
    }
}
