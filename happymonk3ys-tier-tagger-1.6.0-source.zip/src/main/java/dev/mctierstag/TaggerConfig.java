package dev.mctierstag;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import java.nio.file.*;
import java.util.*;

public final class TaggerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public boolean enabled = true;
    public boolean tabList = true;
    public boolean fallback = true;
    public boolean includeRetired = true;
    public int configVersion = 7;
    public boolean showIcon = true;
    public String iconStyle = "classic";
    public String mode = "highest";
    public String tierPalette = "mctiers";
    public Map<String, Integer> tierColors = new TreeMap<>();

    public static TaggerConfig load(Path path) {
        if (!Files.isRegularFile(path)) return new TaggerConfig();
        try {
            var json = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
            TaggerConfig config = GSON.fromJson(json, TaggerConfig.class);
            if (config == null) throw new IllegalArgumentException("Empty config");
            if (!json.has("configVersion")) {
                config.showIcon = true;
            }
            if (config.tierColors == null) config.tierColors = new TreeMap<>();
            // Apply the requested original palette once when upgrading. Later edits remain saved.
            if (!json.has("configVersion") || json.get("configVersion").getAsInt() < 5) {
                config.tierPalette = "mctiers";
                config.tierColors.clear();
            }
            // Replace only the retired color on this upgrade; keep active-tier edits.
            if (!json.has("configVersion") || json.get("configVersion").getAsInt() < 7) config.tierColors.remove("RETIRED");
            config.configVersion = 7;
            if (!"pvptiers".equals(config.tierPalette)) config.tierPalette = "mctiers";
            config.tierColors.entrySet().removeIf(e -> e.getKey() == null || !e.getKey().matches("[HL]T[1-5]|RETIRED")
                    || e.getValue() == null || e.getValue() < 0 || e.getValue() > 0xFFFFFF);
            if (!"mctiers".equals(config.iconStyle)) config.iconStyle = "classic";
            if (config.mode == null || !config.mode.matches("[a-z0-9_\\-]{1,32}")) config.mode = "highest";
            return config;
        } catch (Exception e) {
            MCTiersTagger.LOGGER.warn("Could not read MCTiers settings; using defaults", e);
            try { Files.copy(path, path.resolveSibling(path.getFileName() + ".invalid-" + System.currentTimeMillis())); }
            catch (Exception ignored) {}
            return new TaggerConfig();
        }
    }
    public String iconChoiceLabel() {
        return !showIcon ? "Off" : "mctiers".equals(iconStyle) ? "MCTiers" : "Classic";
    }
    public void cycleIcons() {
        if (!showIcon) { showIcon = true; iconStyle = "classic"; }
        else if ("classic".equals(iconStyle)) iconStyle = "mctiers";
        else showIcon = false;
    }
    public boolean save(Path path) {
        try {
            Files.createDirectories(path.getParent());
            Path temp = path.resolveSibling(path.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(this));
            try { Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (Exception e) {
            MCTiersTagger.LOGGER.error("Could not save MCTiers settings", e);
            return false;
        }
    }
}
