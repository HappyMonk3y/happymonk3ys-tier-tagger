package dev.mctierstag.api;

import com.google.gson.*;
import java.util.*;

public record PlayerProfile(UUID uuid, String name, String region, long overall, int points,
                            Map<String, Ranking> rankings) {
    public record Ranking(int tier, int pos, Integer peakTier, Integer peakPos, boolean retired) {
        public Ranking {
            if (!valid(tier, pos)) throw new IllegalArgumentException("Invalid tier or position");
        }
        public static boolean valid(int tier, int pos) { return tier >= 1 && tier <= 5 && pos >= 0 && pos <= 1; }
        public int displayTier() { return hasRetiredPeak() ? peakTier : tier; }
        public int displayPos() { return hasRetiredPeak() ? peakPos : pos; }
        private boolean hasRetiredPeak() {
            return retired && peakTier != null && peakPos != null && valid(peakTier, peakPos);
        }
        public int strength() { return (displayTier() - 1) * 2 + displayPos(); }
        public String label() { return (displayPos() == 0 ? "HT" : "LT") + displayTier(); }
        public String peakLabel() {
            return peakTier != null && peakPos != null && valid(peakTier, peakPos)
                    ? (peakPos == 0 ? "HT" : "LT") + peakTier : "-";
        }
    }
    public record Selection(String mode, Ranking ranking) {}

    public Optional<Selection> select(String mode, boolean fallback, boolean includeRetired) {
        Ranking selected = rankings.get(mode);
        if (!"highest".equals(mode) && selected != null && (includeRetired || !selected.retired()))
            return Optional.of(new Selection(mode, selected));
        if (!"highest".equals(mode) && !fallback) return Optional.empty();
        return rankings.entrySet().stream()
                .filter(e -> includeRetired || !e.getValue().retired())
                .min(Comparator.<Map.Entry<String, Ranking>>comparingInt(e -> e.getValue().strength())
                        .thenComparing(Map.Entry::getKey))
                .map(e -> new Selection(e.getKey(), e.getValue()));
    }

    public static PlayerProfile parse(String json) {
        JsonObject object = JsonParser.parseString(json).getAsJsonObject();
        UUID uuid = parseUuid(object.get("uuid").getAsString());
        String name = object.get("name").getAsString();
        if (!name.matches("[A-Za-z0-9_]{1,16}")) throw new IllegalArgumentException("Invalid player name");
        if (!object.has("rankings") || !object.get("rankings").isJsonObject())
            throw new IllegalArgumentException("Missing v2 rankings object");
        Map<String, Ranking> rankings = new TreeMap<>();
        for (var entry : object.getAsJsonObject("rankings").entrySet()) {
            if (!entry.getKey().matches("[a-z0-9_\\-]{1,32}")) continue;
            try {
                JsonObject r = entry.getValue().getAsJsonObject();
                // Never default an absent tier/pos to zero: malformed API data must not invent HT1.
                int tier = integer(r.get("tier"));
                int pos = integer(r.get("pos"));
                Integer peakTier = optionalInteger(r.get("peak_tier"));
                Integer peakPos = optionalInteger(r.get("peak_pos"));
                boolean retired = r.has("retired") && r.get("retired").getAsBoolean();
                rankings.put(entry.getKey(), new Ranking(tier, pos, peakTier, peakPos, retired));
            } catch (RuntimeException ignored) {
                // A malformed gamemode cannot break valid rankings from the other modes.
            }
        }
        if (!object.getAsJsonObject("rankings").isEmpty() && rankings.isEmpty())
            throw new IllegalArgumentException("No valid ranking records");
        String region = object.has("region") && !object.get("region").isJsonNull()
                ? object.get("region").getAsString() : "??";
        if (!region.matches("[A-Z?]{2}")) region = "??";
        long overall = object.has("overall") && !object.get("overall").isJsonNull()
                ? object.get("overall").getAsLong() : 0;
        int points = object.has("points") && !object.get("points").isJsonNull()
                ? object.get("points").getAsInt() : 0;
        return new PlayerProfile(uuid, name, region, overall, points, Collections.unmodifiableMap(rankings));
    }

    private static int integer(JsonElement value) {
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber())
            throw new IllegalArgumentException("Expected integer");
        return value.getAsBigDecimal().intValueExact();
    }
    private static Integer optionalInteger(JsonElement value) {
        if (value == null || value.isJsonNull()) return null;
        try { return integer(value); } catch (RuntimeException ignored) { return null; }
    }
    public static UUID parseUuid(String value) {
        if (value.matches("[a-fA-F0-9]{32}")) value = value.replaceFirst(
                "(.{8})(.{4})(.{4})(.{4})(.{12})", "$1-$2-$3-$4-$5");
        if (!value.matches("[a-fA-F0-9]{8}(-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}"))
            throw new IllegalArgumentException("Invalid UUID");
        return UUID.fromString(value);
    }
}
