package dev.mctierstag;

import dev.mctierstag.api.PlayerProfile;
import java.util.*;

/** User-requested cosmetic tiers. Kept separate from the API and its cache. */
public final class LocalTierOverrides {
    public static final String PLAYER = "HappyMonk3y";
    private static final PlayerProfile.Ranking CRYSTAL = new PlayerProfile.Ranking(2, 1, 2, 1, true);
    private static final PlayerProfile.Ranking OTHER = new PlayerProfile.Ranking(3, 1, null, null, false);
    private LocalTierOverrides() {}
    public static boolean appliesTo(String name) { return PLAYER.equalsIgnoreCase(name); }
    public static Map<String, PlayerProfile.Ranking> rankings(Collection<String> modes) {
        Map<String, PlayerProfile.Ranking> result = new TreeMap<>();
        for (String mode : modes) result.put(mode, mode.equals("vanilla") || mode.equals("crystal") ? CRYSTAL : OTHER);
        result.putIfAbsent("vanilla", CRYSTAL);
        return Collections.unmodifiableMap(result);
    }
    public static PlayerProfile profile(UUID uuid, Collection<String> modes) {
        return new PlayerProfile(uuid, PLAYER, "", 0, 0, rankings(modes));
    }
}
