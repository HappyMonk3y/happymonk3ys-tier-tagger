package dev.mctierstag.ui;

import dev.mctierstag.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.function.*;

public final class ExtraOptionsScreen extends Screen {
    private final Screen parent;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private String status = "";
    public ExtraOptionsScreen(Screen parent) { super(Text.literal("More options")); this.parent = parent; }
    @Override protected void init() {
        int w = Math.min(280, width - 24), x = (width - w) / 2;
        var c = mod.config;
        toggle(x, 62, w, "Tab list", () -> c.tabList, v -> c.tabList = v);
        toggle(x, 90, w, "Highest-tier fallback", () -> c.fallback, v -> c.fallback = v);
        toggle(x, 118, w, "Show retired tiers", () -> c.includeRetired, v -> c.includeRetired = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("Refresh tiers"), b -> {
            mod.api.clearCache(); status = "Player tiers will reload.";
        }).dimensions(x, 152, w, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(x, height - 32, w, 20).build());
    }
    private void toggle(int x, int y, int w, String label, BooleanSupplier getter, Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label + ": " + (getter.getAsBoolean() ? "ON" : "OFF")), b -> {
            setter.accept(!getter.getAsBoolean()); b.setMessage(Text.literal(label + ": " + (getter.getAsBoolean() ? "ON" : "OFF")));
            if (!mod.save()) status = "Could not save settings.";
        }).dimensions(x, y, w, 20).build());
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 22, 0xFF75D8FF);
        context.drawCenteredTextWithShadow(textRenderer, status, width / 2, height - 50, 0xFFAAAAAA);
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
