package dev.mctierstag.ui;

import dev.mctierstag.*;
import dev.mctierstag.api.PlayerProfile.Ranking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public final class SettingsScreen extends Screen {
    private final Screen parent;
    private final MCTiersTagger mod = MCTiersTagger.get();
    private String status = "";
    private String searchValue = "";
    private TextFieldWidget search;
    private int left, panelWidth, optionsY, searchY;
    public SettingsScreen(Screen parent) { super(Text.literal(MCTiersTagger.NAME)); this.parent = parent; }
    @Override protected void init() {
        mod.api.loadModes();
        panelWidth = Math.min(320, width - 24); left = (width - panelWidth) / 2;
        int half = (panelWidth - 8) / 2;
        optionsY = Math.max(100, height / 2 - 32);
        TaggerConfig c = mod.config;
        addDrawableChild(ButtonWidget.builder(Text.literal("Icons: " + c.iconChoiceLabel()), b -> {
            c.cycleIcons(); b.setMessage(Text.literal("Icons: " + c.iconChoiceLabel())); persist();
        }).dimensions(left, optionsY + 14, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Tier colors..."), b -> client.setScreen(new TierColorsScreen(this)))
                .dimensions(left + half + 8, optionsY + 14, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Mode: " + mod.api.modeTitle(c.mode)), b -> {
            List<String> modes = new ArrayList<>(); modes.add("highest"); modes.addAll(mod.api.modes().keySet());
            c.mode = modes.get((modes.indexOf(c.mode) + 1) % modes.size());
            b.setMessage(Text.literal("Mode: " + mod.api.modeTitle(c.mode))); persist();
        }).dimensions(left, optionsY + 42, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Tags: " + (c.enabled ? "ON" : "OFF")), b -> {
            c.enabled = !c.enabled; b.setMessage(Text.literal("Tags: " + (c.enabled ? "ON" : "OFF"))); persist();
        }).dimensions(left + half + 8, optionsY + 42, half, 20).build());
        searchY = Math.min(optionsY + 76, height - 68);
        search = new TextFieldWidget(textRenderer, left, searchY, panelWidth - 84, 20, Text.literal("Minecraft username"));
        search.setMaxLength(16); search.setPlaceholder(Text.literal("Search player..."));
        search.setText(searchValue); search.setChangedListener(value -> searchValue = value); addDrawableChild(search);
        addDrawableChild(ButtonWidget.builder(Text.literal("Search"), b -> lookup())
                .dimensions(left + panelWidth - 76, searchY, 76, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("More options..."), b -> client.setScreen(new ExtraOptionsScreen(this)))
                .dimensions(left, height - 32, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + half + 8, height - 32, half, 20).build());
    }
    private void persist() { if (!mod.save()) status = "Could not save settings; check the Minecraft log."; }
    private void lookup() {
        String name = search.getText().trim();
        if (!name.matches("[A-Za-z0-9_]{1,16}")) { status = "Enter a valid Minecraft username."; return; }
        status = "";
        client.setScreen(new ProfileScreen(this, name));
    }
    @Override public boolean keyPressed(KeyInput input) {
        if (search.isFocused() && (input.key() == GLFW.GLFW_KEY_ENTER || input.key() == GLFW.GLFW_KEY_KP_ENTER)) {
            lookup(); return true;
        }
        return super.keyPressed(input);
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 22, 0xFF75D8FF);
        context.fill(left, 50, left + panelWidth, 88, 0x70313A49);
        context.drawCenteredTextWithShadow(textRenderer, "Preview", width / 2, 56, 0xFFAAAAAA);
        String mode = mod.config.mode.equals("highest") ? "vanilla" : mod.config.mode;
        Text preview = TierBadge.decorate(Text.literal("PlayerName"), new Ranking(3, 1, null, null, false), mode, mod.config);
        context.drawCenteredTextWithShadow(textRenderer, preview, width / 2, 72, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "Options", left, optionsY, 0xFFBBBBBB);
        context.drawCenteredTextWithShadow(textRenderer, textRenderer.trimToWidth(status, width - 16), width / 2, searchY + 23, 0xFFAAAAAA);
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
