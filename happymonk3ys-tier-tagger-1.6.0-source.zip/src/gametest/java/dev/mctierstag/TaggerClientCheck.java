package dev.mctierstag;

import com.terraformersmc.modmenu.ModMenu;
import dev.mctierstag.api.PlayerProfile;
import dev.mctierstag.ui.*;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;

/** Separate development-only entrypoint; never included in the release JAR. */
public final class TaggerClientCheck implements FabricClientGameTest {
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
    }
    @Override public void runTest(ClientGameTestContext context) {
        context.waitForScreen(TitleScreen.class);
        context.getInput().resizeWindow(960, 600);
        context.runOnClient(client -> {
            MCTiersTagger.get().config = new TaggerConfig();
            check(ModMenu.hasConfigScreen("mctiers_tagger"), "Mod Menu discovers config factory");
            check(ModMenu.MODS.get("mctiers_tagger").getName().equals(MCTiersTagger.NAME), "Mod Menu shows renamed mod");
            var screen = ModMenu.getConfigScreen("mctiers_tagger", client.currentScreen);
            check(screen instanceof SettingsScreen, "Mod Menu creates settings screen");
            client.setScreen(screen);
            var buttons = screen.children().stream().filter(net.minecraft.client.gui.widget.ButtonWidget.class::isInstance)
                    .map(net.minecraft.client.gui.widget.ButtonWidget.class::cast).toList();
            check(buttons.size() == 7, "main settings has four options, search and two footer buttons");
            check(buttons.getFirst().getMessage().getString().equals("Icons: Classic"), "icons first in options");
            check(buttons.getFirst().getX() < buttons.get(1).getX() && buttons.getFirst().getY() == buttons.get(1).getY(), "icons at top left");
            check(buttons.stream().noneMatch(b -> b.getMessage().getString().matches(".*(Above names|Position:|Mode label).*")), "removed controls absent");
            var rank = new PlayerProfile.Ranking(3, 1, null, null, false);
            var config = new TaggerConfig();
            var name = Text.literal("PlayerName").withColor(0x55FFFF);
            var badge = TierBadge.decorate(name, rank, "sword", config);
            check(badge.getString().equals(TierBadge.glyph("sword") + " LT3 PlayerName"), "compact classic sword label");
            check(TierBadge.color(rank) == 0xC67B42, "original MCTiers LT3 color");
            check(name.getString().equals("PlayerName"), "original name is not mutated");
            var icons = java.util.Map.of("vanilla", "crystal", "uhc", "uhc", "pot", "pot", "nethop", "neth_pot",
                    "smp", "smp", "sword", "sword", "axe", "axe", "mace", "mace");
            var uniqueGlyphs = new java.util.HashSet<String>();
            icons.forEach((mode, file) -> {
                uniqueGlyphs.add(TierBadge.glyph(mode));
                check(client.textRenderer.getWidth(TierBadge.icon(mode, "classic")) > 0, mode + " classic glyph has positive width");
                check(client.getResourceManager().getResource(net.minecraft.util.Identifier.of("mctiers_tagger",
                        "textures/font/classic/" + file + ".png")).isPresent(), mode + " texture is present");
                String mctiersFile = mode.equals("nethop") ? "neth_op" : mode;
                check(client.getResourceManager().getResource(net.minecraft.util.Identifier.of("mctiers_tagger",
                        "textures/font/mctiers/" + mctiersFile + ".png")).isPresent(), mode + " MCTiers texture is present");
                check(client.textRenderer.getWidth(TierBadge.icon(mode, "mctiers")) > 0, mode + " MCTiers glyph has positive width");
                check(!TierBadge.icon(mode, "classic").getStyle().getFont().equals(TierBadge.icon(mode, "mctiers").getStyle().getFont()),
                        mode + " styles use different fonts");
            });
            check(uniqueGlyphs.size() == 8, "all eight gamemodes have different icons");
            check(TierBadge.glyph("vanilla").equals(TierBadge.glyph("crystal")), "v2 vanilla maps to Crystal");
            check(TierBadge.glyph("nethop").equals(TierBadge.glyph("neth_pot")), "v2 nethop maps to NethPot");
            check(!uniqueGlyphs.contains(TierBadge.glyph("future_mode")), "unknown modes have a generic fallback");
            check(TierBadge.icon("future_mode", "classic").equals(TierBadge.icon("future_mode", "mctiers")), "both styles retain future-mode fallback");
            check(TierBadge.tier(new PlayerProfile.Ranking(2, 1, 2, 1, true), config).getString().equals("RLT2"), "retired prefix format");
            verifyConfigMigration();
            verifyPalette(config);
        });
        context.waitTicks(3);
        context.takeScreenshot("happymonk3y-classic-settings");
        context.clickScreenButton("Icons: Classic");
        context.runOnClient(client -> {
            check(MCTiersTagger.get().config.iconChoiceLabel().equals("MCTiers"), "button selects MCTiers");
            var saved = TaggerConfig.load(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("mctiers-tagger.json"));
            check(saved.showIcon && saved.iconStyle.equals("mctiers"), "MCTiers choice survives save/reload");
            var config = MCTiersTagger.get().config;
            var badge = TierBadge.label("sword", new PlayerProfile.Ranking(3, 1, null, null, false), config);
            check(badge.getSiblings().getFirst().getStyle().getFont().equals(TierBadge.icon("sword", "mctiers").getStyle().getFont()),
                    "selected style reaches nametag label");
        });
        context.waitTicks(3);
        context.takeScreenshot("happymonk3y-mctiers-settings");
        context.clickScreenButton("Icons: MCTiers");
        context.runOnClient(client -> {
            var config = MCTiersTagger.get().config;
            check(!config.showIcon && config.iconChoiceLabel().equals("Off"), "button disables icons");
            check(TierBadge.label("sword", new PlayerProfile.Ranking(3, 1, null, null, false), config).getString().equals("LT3"),
                    "off removes glyph and padding");
        });
        context.clickScreenButton("Icons: Off");
        context.runOnClient(client -> check(MCTiersTagger.get().config.iconChoiceLabel().equals("Classic"), "selector cycles back to Classic"));
        context.clickScreenButton("Icons: Classic");
        context.clickScreenButton("Tier colors...");
        context.waitForScreen(TierColorsScreen.class);
        context.waitTicks(3);
        context.takeScreenshot("happymonk3y-tier-colors");
        context.clickScreenButton("Palette: MCTiers");
        context.runOnClient(client -> {
            check(MCTiersTagger.get().config.tierPalette.equals("pvptiers"), "PvPTiers preset selected");
            verifyPalette(MCTiersTagger.get().config);
            var saved = TaggerConfig.load(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("mctiers-tagger.json"));
            check(saved.tierPalette.equals("pvptiers"), "palette survives save/reload");
        });
        context.clickScreenButton("Palette: PvPTiers");
        context.runOnClient(client -> verifyPalette(MCTiersTagger.get().config));
        context.clickScreenButton("Retired  #8FB6DC");
        context.waitForScreen(TierColorScreen.class);
        context.clickScreenButton("Cyan");
        context.runOnClient(client -> check(MCTiersTagger.get().config.tierColors.get("RETIRED") == 0x55FFFF
                && !MCTiersTagger.get().config.tierColors.containsKey("LT2"), "retired editor has its own color"));
        context.clickScreenButton("Reset color");
        context.runOnClient(client -> check(TierBadge.color(new PlayerProfile.Ranking(2, 1, 2, 1, true), MCTiersTagger.get().config) == 0x8FB6DC, "reset retired to requested blue"));
        context.waitTicks(3);
        context.takeScreenshot("happymonk3y-retired-color");
        context.clickScreenButton("Done");
        context.waitForScreen(TierColorsScreen.class);
        context.clickScreenButton("LT3  #C67B42");
        context.waitForScreen(TierColorScreen.class);
        context.clickScreenButton("Cyan");
        context.runOnClient(client -> {
            var config = MCTiersTagger.get().config;
            check(config.tierColors.get("LT3") == 0x55FFFF, "swatch updates only selected tier");
            check(config.tierColors.size() == 1, "other tier colors unchanged");
            var rank = new PlayerProfile.Ranking(3, 1, null, null, false);
            check(TierBadge.tier(rank, config).getStyle().getColor().getRgb() == 0x55FFFF, "custom color reaches shared tier text");
            var field = client.currentScreen.children().stream().filter(net.minecraft.client.gui.widget.TextFieldWidget.class::isInstance)
                    .map(net.minecraft.client.gui.widget.TextFieldWidget.class::cast).findFirst().orElseThrow();
            field.setText("#zzzzzz");
            var apply = client.currentScreen.children().stream().filter(net.minecraft.client.gui.widget.ButtonWidget.class::isInstance)
                    .map(net.minecraft.client.gui.widget.ButtonWidget.class::cast).filter(b -> b.getMessage().getString().equals("Apply")).findFirst().orElseThrow();
            check(!apply.active && config.tierColors.get("LT3") == 0x55FFFF, "invalid hex cannot overwrite saved color");
            field.setText("#123ABC");
            check(apply.active, "valid hex can be applied");
        });
        context.clickScreenButton("Apply");
        context.runOnClient(client -> {
            var saved = TaggerConfig.load(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("mctiers-tagger.json"));
            check(saved.tierColors.get("LT3") == 0x123ABC, "hex color survives save/reload");
        });
        context.clickScreenButton("Reset color");
        context.runOnClient(client -> check(MCTiersTagger.get().config.tierColors.isEmpty(), "reset removes custom tier color"));
        context.clickScreenButton("Cyan");
        context.waitTicks(3);
        context.takeScreenshot("happymonk3y-color-picker");
        // Verify the compact layout at Minecraft's minimum logical GUI size too.
        context.getInput().resizeWindow(640, 480);
        context.waitTicks(3);
        context.runOnClient(client -> {
            for (var child : client.currentScreen.children()) if (child instanceof net.minecraft.client.gui.widget.ClickableWidget widget)
                check(widget.getY() >= 0 && widget.getY() + widget.getHeight() <= client.currentScreen.height, "color controls fit small window");
        });
        context.takeScreenshot("happymonk3y-color-picker-small");
        context.clickScreenButton("Done");
        context.waitForScreen(TierColorsScreen.class);
        context.runOnClient(client -> {
            var widgets = client.currentScreen.children().stream().filter(net.minecraft.client.gui.widget.ClickableWidget.class::isInstance)
                    .map(net.minecraft.client.gui.widget.ClickableWidget.class::cast).toList();
            for (int i = 0; i < widgets.size(); i++) {
                var a = widgets.get(i);
                check(a.getY() + a.getHeight() <= client.currentScreen.height, "palette controls fit minimum window");
                for (int j = i + 1; j < widgets.size(); j++) {
                    var b = widgets.get(j);
                    check(a.getX() + a.getWidth() <= b.getX() || b.getX() + b.getWidth() <= a.getX()
                            || a.getY() + a.getHeight() <= b.getY() || b.getY() + b.getHeight() <= a.getY(), "palette controls do not overlap");
                }
            }
        });
        context.waitTicks(3);
        context.takeScreenshot("happymonk3y-palette-small");
        context.getInput().resizeWindow(960, 600);
        context.clickScreenButton("Reset all colors");
        context.runOnClient(client -> verifyPalette(MCTiersTagger.get().config));
        context.clickScreenButton("Done");
        context.waitForScreen(SettingsScreen.class);
        context.runOnClient(client -> {
            var field = client.currentScreen.children().stream().filter(net.minecraft.client.gui.widget.TextFieldWidget.class::isInstance)
                    .map(net.minecraft.client.gui.widget.TextFieldWidget.class::cast).findFirst().orElseThrow();
            field.setText("!invalid");
        });
        context.clickScreenButton("Search");
        context.runOnClient(client -> {
            check(client.currentScreen instanceof SettingsScreen, "invalid search stays in settings");
            var field = client.currentScreen.children().stream().filter(net.minecraft.client.gui.widget.TextFieldWidget.class::isInstance)
                    .map(net.minecraft.client.gui.widget.TextFieldWidget.class::cast).findFirst().orElseThrow();
            field.setText("HappyMonk3y");
        });
        context.clickScreenButton("Search");
        context.waitForScreen(ProfileScreen.class);
        context.clickScreenButton("Back");
        context.waitForScreen(SettingsScreen.class);
        context.runOnClient(client -> {
            var field = client.currentScreen.children().stream().filter(net.minecraft.client.gui.widget.TextFieldWidget.class::isInstance)
                    .map(net.minecraft.client.gui.widget.TextFieldWidget.class::cast).findFirst().orElseThrow();
            check(field.getText().equals("HappyMonk3y"), "search preserves username on return");
            field.setText("");
        });
        context.waitTicks(3);
        context.takeScreenshot("happymonk3y-simple-settings");
        context.clickScreenButton("More options...");
        context.waitForScreen(ExtraOptionsScreen.class);
        context.clickScreenButton("Done");
        context.waitForScreen(SettingsScreen.class);
        context.runOnClient(client -> client.currentScreen.close());
        context.waitForScreen(TitleScreen.class);
        // Creating a disposable local world also verifies command registration and the chat-to-profile transition.
        try (var world = context.worldBuilder().create()) {
            context.runOnClient(client -> {
                var dispatcher = ClientCommandManager.getActiveDispatcher();
                check(dispatcher != null && dispatcher.getRoot().getChild("tiers") != null, "/tiers is registered");
                check(dispatcher.getRoot().getChild("mctiers") == null, "legacy /mctiers removed");
                client.getNetworkHandler().sendChatCommand("tiers uku3lig");
            });
            context.waitForScreen(ProfileScreen.class);
            context.waitFor(client -> MCTiersTagger.get().api.lookupName("uku3lig").isDone(), 400);
            context.waitTicks(3);
            context.runOnClient(client -> {
                var result = MCTiersTagger.get().api.lookupName("uku3lig").join();
                check(result.profile() != null, "live profile loaded in game");
                var entry = new net.minecraft.client.network.PlayerListEntry(
                        new com.mojang.authlib.GameProfile(result.profile().uuid(), result.profile().name()), false);
                Text tab = client.inGameHud.getPlayerListHud().getPlayerName(entry);
                String mode = result.profile().select("highest", true, true).orElseThrow().mode();
                check(tab.getString().contains(TierBadge.glyph(mode)), "tab mixin adds the matching gamemode icon");
                check(tab.getString().contains(result.profile().name()), "tab mixin preserves player name");
            });
            context.takeScreenshot("happymonk3y-classic-profile");
            context.runOnClient(client -> {
                MCTiersTagger.get().config.iconStyle = "mctiers";
                var profile = MCTiersTagger.get().api.lookupName("uku3lig").join().profile();
                var entry = new net.minecraft.client.network.PlayerListEntry(new com.mojang.authlib.GameProfile(profile.uuid(), profile.name()), false);
                var tab = client.inGameHud.getPlayerListHud().getPlayerName(entry);
                String mode = profile.select("highest", true, true).orElseThrow().mode();
                var font = tab.visit((style, segment) -> segment.contains(TierBadge.glyph(mode)) ? java.util.Optional.of(style.getFont()) : java.util.Optional.empty(), net.minecraft.text.Style.EMPTY).orElseThrow();
                check(font.equals(TierBadge.icon(mode, "mctiers").getStyle().getFont()), "tab mixin follows selected MCTiers style");
            });
            context.waitTicks(3);
            context.takeScreenshot("happymonk3y-mctiers-profile");
            context.runOnClient(client -> client.currentScreen.close());
            context.waitForScreen(null);
            context.runOnClient(client -> {
                var mod = MCTiersTagger.get();
                var uuid = java.util.UUID.randomUUID();
                check(LocalTierOverrides.appliesTo("happymonk3y") && !LocalTierOverrides.appliesTo("HappyMonk3y_"), "override only matches exact username");
                for (String mode : mod.api.modes().keySet()) {
                    mod.config.mode = mode;
                    String expected = mode.equals("vanilla") || mode.equals("crystal") ? "RLT2" : "LT3";
                    var tag = mod.decorate(uuid, "HappyMonk3y", Text.literal("HappyMonk3y"), false);
                    check(tag.getString().equals(TierBadge.glyph(mode) + " " + expected + " HappyMonk3y"), "custom nametag for " + mode);
                }
                mod.config.mode = "highest";
                var entry = new net.minecraft.client.network.PlayerListEntry(new com.mojang.authlib.GameProfile(uuid, "HappyMonk3y"), false);
                var tab = client.inGameHud.getPlayerListHud().getPlayerName(entry);
                check(tab.getString().equals(TierBadge.glyph("vanilla") + " RLT2 HappyMonk3y"), "tab mixin uses custom Crystal rank");
                var retiredColor = tab.visit((style, text) -> text.equals("RLT2") ? java.util.Optional.of(style.getColor().getRgb()) : java.util.Optional.<Integer>empty(), net.minecraft.text.Style.EMPTY).orElseThrow();
                check(retiredColor == 0x8FB6DC, "RLT2 uses requested retired blue in tab");
                mod.config.mode = "sword";
                var sword = client.inGameHud.getPlayerListHud().getPlayerName(entry);
                var tierColor = sword.visit((style, text) -> text.equals("LT3") ? java.util.Optional.of(style.getColor().getRgb()) : java.util.Optional.<Integer>empty(), net.minecraft.text.Style.EMPTY).orElseThrow();
                check(tierColor == 0xC67B42, "original MCTiers LT3 reaches tab mixin");
                mod.config.mode = "highest";
                client.getNetworkHandler().sendChatCommand("tiers HappyMonk3y");
            });
            context.waitForScreen(ProfileScreen.class);
            context.waitTicks(3);
            context.takeScreenshot("happymonk3y-custom-profile");
            context.runOnClient(client -> client.currentScreen.close());
            context.waitForScreen(null);
            verifyWorldTags(context);
        }
        System.out.println("PASS: offline-UUID overhead tags before/after teleport, exact palettes, #8FB6DC retired tiers, GUI, tab and /tiers");
    }
    private static void verifyWorldTags(ClientGameTestContext context) {
        context.waitTicks(3);
        context.runOnClient(client -> {
            var mod = MCTiersTagger.get();
            mod.config.mode = "highest";
            client.player.setYaw(0); client.player.setPitch(-8);
            double x = client.player.getX(), y = client.player.getY(), z = client.player.getZ();
            var profile = mod.api.lookupName("uku3lig").join().profile();
            var offlineId = java.util.UUID.nameUUIDFromBytes("OfflinePlayer:uku3lig".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            check(!offlineId.equals(profile.uuid()), "world test uses an offline UUID");
            var remote = new net.minecraft.client.network.OtherClientPlayerEntity(client.world, new com.mojang.authlib.GameProfile(offlineId, "uku3lig"));
            remote.setId(1000001);
            remote.refreshPositionAndAngles(x - 1.5, y, z + 5, 180, 0);
            client.world.addEntity(remote);
            var renderer = client.getEntityRenderDispatcher().getPlayerRenderer(remote);
            var state = renderer.createRenderState();
            renderer.updateRenderState(remote, state, 1);
            var selected = profile.select("highest", true, true).orElseThrow();
            String expected = TierBadge.glyph(selected.mode()) + " " + TierBadge.tier(selected.ranking(), mod.config).getString() + " uku3lig";
            check(state.displayName != null && state.displayName.getString().equals(expected), "actual overhead render state has tier for offline player");
            renderer.updateRenderState(remote, state, 1);
            check(state.displayName.getString().equals(expected), "repeated world rendering does not duplicate badge");
            remote.refreshPositionAndAngles(x - 1.5, y, z + 100, 180, 0);
            renderer.updateRenderState(remote, state, 1);
            check(state.displayName == null, "vanilla name-distance limit is preserved");
            remote.refreshPositionAndAngles(x - 1.5, y, z + 5, 180, 0);
            renderer.updateRenderState(remote, state, 1);
            check(state.displayName != null && state.displayName.getString().equals(expected), "overhead tier returns immediately after teleport");
            var tabEntry = new net.minecraft.client.network.PlayerListEntry(remote.getGameProfile(), false);
            check(client.inGameHud.getPlayerListHud().getPlayerName(tabEntry).getString().equals(expected), "offline tab and overhead labels match");
            var happyId = java.util.UUID.nameUUIDFromBytes("OfflinePlayer:HappyMonk3y".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            var happy = new net.minecraft.client.network.OtherClientPlayerEntity(client.world, new com.mojang.authlib.GameProfile(happyId, "HappyMonk3y"));
            happy.setId(1000002); happy.refreshPositionAndAngles(x + 1.5, y, z + 5, 180, 0); client.world.addEntity(happy);
            var happyState = client.getEntityRenderDispatcher().getPlayerRenderer(happy).getAndUpdateRenderState(happy, 1);
            check(happyState.displayName != null && happyState.displayName.getString().equals(TierBadge.glyph("vanilla") + " RLT2 HappyMonk3y"), "custom HappyMonk3y rank also appears overhead with offline UUID");
            var color = happyState.displayName.visit((style, text) -> text.equals("RLT2") ? java.util.Optional.of(style.getColor().getRgb()) : java.util.Optional.<Integer>empty(), net.minecraft.text.Style.EMPTY).orElseThrow();
            check(color == 0x8FB6DC, "overhead RLT2 uses selected blue");
        });
        context.waitTicks(5);
        context.takeScreenshot("happymonk3y-offline-overhead");
        context.runOnClient(client -> {
            client.world.removeEntity(1000001, net.minecraft.entity.Entity.RemovalReason.DISCARDED);
            client.world.removeEntity(1000002, net.minecraft.entity.Entity.RemovalReason.DISCARDED);
        });
    }
    private static void verifyConfigMigration() {
        java.nio.file.Path temp = null;
        try {
            temp = java.nio.file.Files.createTempFile("tagger-config-check", ".json");
            java.nio.file.Files.writeString(temp, "{\"configVersion\":3,\"nametags\":false,\"prefix\":false,\"showMode\":true,\"showIcon\":false,\"iconStyle\":\"mctiers\",\"tierColors\":{\"LT3\":1193046,\"LT2\":16777216,\"HT1\":-1,\"unknown\":255}}");
            var loaded = TaggerConfig.load(temp);
            check(loaded.configVersion == 7 && !loaded.showIcon && loaded.iconStyle.equals("mctiers"), "old icon preference preserved");
            check(loaded.tierColors.isEmpty() && loaded.tierPalette.equals("mctiers"), "upgrade applies requested original palette once");
            check(TierBadge.decorate(Text.literal("PlayerName"), new PlayerProfile.Ranking(3, 1, null, null, false), "sword", loaded).getString().equals("LT3 PlayerName"), "removed legacy options cannot alter compact tags");
            java.nio.file.Files.writeString(temp, "{\"configVersion\":5,\"tierPalette\":\"pvptiers\",\"tierColors\":{\"LT3\":1193046,\"LT2\":16777216,\"RETIRED\":6986705,\"unknown\":255}}");
            loaded = TaggerConfig.load(temp);
            check(loaded.tierPalette.equals("pvptiers") && loaded.tierColors.size() == 1 && loaded.tierColors.get("LT3") == 0x123456, "retired upgrade keeps active colors and palette");
            check(TierBadge.color(new PlayerProfile.Ranking(2, 1, 2, 1, true), loaded) == 0x8FB6DC, "old retired color replaced by selected blue");
            loaded.tierColors.put("RETIRED", 0x123456);
            check(loaded.save(temp) && TaggerConfig.load(temp).tierColors.get("RETIRED") == 0x123456, "later retired customization persists");
        } catch (java.io.IOException e) { throw new AssertionError(e); }
        finally { if (temp != null) try { java.nio.file.Files.deleteIfExists(temp); } catch (java.io.IOException e) { throw new AssertionError(e); } }
    }
    private static void verifyPalette(TaggerConfig config) {
        try (var in = TaggerClientCheck.class.getResourceAsStream("/" + config.tierPalette + "-colors-upstream.json")) {
            check(in != null, "upstream palette fixture present");
            var source = com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
            for (int tier = 1; tier <= 5; tier++) for (int pos = 0; pos <= 1; pos++) {
                var rank = new PlayerProfile.Ranking(tier, pos, null, null, false);
                int expected = Integer.parseInt(source.get(rank.label().toLowerCase(java.util.Locale.ROOT)).getAsString().substring(1), 16);
                check(TierBadge.color(rank, config) == expected, config.tierPalette + " exact " + rank.label());
                var retired = new PlayerProfile.Ranking(tier, pos, tier, pos, true);
                check(TierBadge.color(retired, config) == 0x8FB6DC, "all retired tiers use requested blue");
            }
        } catch (java.io.IOException e) { throw new AssertionError(e); }
    }
}
